var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
System.register("commons/RamAPI", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var RAMMessageType, ErrorResponse, RelationshipTableReq, EmptyRelationshipTableRes;
    return {
        setters:[],
        execute: function() {
            (function (RAMMessageType) {
                RAMMessageType[RAMMessageType["Error"] = 1] = "Error";
                RAMMessageType[RAMMessageType["Info"] = 2] = "Info";
                RAMMessageType[RAMMessageType["Success"] = 3] = "Success";
            })(RAMMessageType || (RAMMessageType = {}));
            exports_1("RAMMessageType", RAMMessageType);
            ErrorResponse = (function () {
                function ErrorResponse(status, message) {
                    this.status = status;
                    this.message = { message: message, messageType: RAMMessageType.Error };
                }
                return ErrorResponse;
            }());
            exports_1("ErrorResponse", ErrorResponse);
            RelationshipTableReq = (function () {
                function RelationshipTableReq(pageSize, pageNumber, canActFor, filters, sortByField) {
                    this.pageSize = pageSize;
                    this.pageNumber = pageNumber;
                    this.canActFor = canActFor;
                    this.filters = filters;
                    this.sortByField = sortByField;
                }
                return RelationshipTableReq;
            }());
            exports_1("RelationshipTableReq", RelationshipTableReq);
            EmptyRelationshipTableRes = (function () {
                function EmptyRelationshipTableRes() {
                    this.total = 0;
                    this.table = new Array();
                    this.relationshipOptions = new Array();
                    this.accessLevelOptions = new Array();
                    this.statusValueOptions = new Array();
                }
                return EmptyRelationshipTableRes;
            }());
            exports_1("EmptyRelationshipTableRes", EmptyRelationshipTableRes);
        }
    }
});
System.register("frontend/typescript/services/ram-rest.service", ['angular2/core', 'angular2/http'], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var core_1, http_1;
    var RAMRestService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            RAMRestService = (function () {
                function RAMRestService(http) {
                    this.http = http;
                }
                RAMRestService.prototype.getRelationshipTableData = function (identityResolver, identityValue, isDelegate, relPathIds, filters, pageNo, pageSize) {
                    var url = ("/api/v1/relationship/table/" + (isDelegate ? 'delegate' : 'subject'))
                        +
                            ("/" + identityValue + "/" + identityResolver + "/page/" + pageNo + "/size/" + pageSize);
                    return this.http.get(url).map(this.extractData).publishReplay().refCount();
                };
                RAMRestService.prototype.extractData = function (res) {
                    if (res.status < 200 || res.status >= 300) {
                        throw new Error('Status code is:' + res.status);
                    }
                    var body = res.json();
                    return body.data || {};
                };
                RAMRestService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], RAMRestService);
                return RAMRestService;
            }());
            exports_2("RAMRestService", RAMRestService);
        }
    }
});
System.register("frontend/typescript/services/ram-nav.service", ['angular2/core', 'rxjs'], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var core_2, rxjs_1;
    var RAMNavService;
    return {
        setters:[
            function (core_2_1) {
                core_2 = core_2_1;
            },
            function (rxjs_1_1) {
                rxjs_1 = rxjs_1_1;
            }],
        execute: function() {
            RAMNavService = (function () {
                function RAMNavService() {
                    this._navSource = new rxjs_1.ReplaySubject(1);
                    this._navObservable$ = this._navSource.asObservable();
                    this.navigateToRel([]);
                }
                Object.defineProperty(RAMNavService.prototype, "navObservable$", {
                    get: function () {
                        return this._navObservable$;
                    },
                    enumerable: true,
                    configurable: true
                });
                RAMNavService.prototype.navigateToRel = function (relIds) {
                    this._navSource.next(relIds);
                };
                RAMNavService = __decorate([
                    core_2.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], RAMNavService);
                return RAMNavService;
            }());
            exports_3("RAMNavService", RAMNavService);
        }
    }
});
System.register("frontend/typescript/services/ram-constants.service", ['angular2/core'], function(exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var core_3;
    var RAMConstantsService;
    return {
        setters:[
            function (core_3_1) {
                core_3 = core_3_1;
            }],
        execute: function() {
            RAMConstantsService = (function () {
                function RAMConstantsService() {
                    this.PageSizeOptions = [5, 10, 25, 100];
                    this.DefaultPageSize = 5;
                    this.PartyId = '5719bc5d65cae16c197e1ecd';
                }
                RAMConstantsService = __decorate([
                    core_3.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], RAMConstantsService);
                return RAMConstantsService;
            }());
            exports_4("RAMConstantsService", RAMConstantsService);
        }
    }
});
System.register("frontend/typescript/components/relationships-table/relationships-table.component", ['angular2/core', 'angular2/router', 'angular2/common', "frontend/typescript/services/ram-constants.service", "frontend/typescript/services/ram-nav.service", "frontend/typescript/services/ram-rest.service"], function(exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var core_4, router_1, common_1, ram_constants_service_1, ram_nav_service_1, ram_rest_service_1;
    var RelationshipsTableComponent;
    return {
        setters:[
            function (core_4_1) {
                core_4 = core_4_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ram_constants_service_1_1) {
                ram_constants_service_1 = ram_constants_service_1_1;
            },
            function (ram_nav_service_1_1) {
                ram_nav_service_1 = ram_nav_service_1_1;
            },
            function (ram_rest_service_1_1) {
                ram_rest_service_1 = ram_rest_service_1_1;
            }],
        execute: function() {
            RelationshipsTableComponent = (function () {
                function RelationshipsTableComponent(constants, routeParams, nav, rest) {
                    var _this = this;
                    this.constants = constants;
                    this.routeParams = routeParams;
                    this.nav = nav;
                    this.rest = rest;
                    this._isLoading = false;
                    this._pageNo = 1;
                    this._relIds = new Array();
                    this._pageSizeOptions = [5, 10, 25, 100];
                    this._filters$ = new common_1.ControlGroup({
                        'name': new common_1.Control(''),
                        'accessLevel': new common_1.Control(''),
                        'relationship': new common_1.Control(''),
                        'status': new common_1.Control('')
                    });
                    this._filters$.valueChanges.debounceTime(500).subscribe(function () { return _this.refreshContents(_this._relIds); });
                    this._pageSizeOptions = constants.PageSizeOptions;
                    this._pageSize = constants.DefaultPageSize;
                }
                Object.defineProperty(RelationshipsTableComponent.prototype, "isLoading", {
                    get: function () {
                        return this._isLoading;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "delegate", {
                    get: function () {
                        return this._delegate;
                    },
                    set: function (value) {
                        this._delegate = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "pageSizeOptions", {
                    get: function () {
                        return this._pageSizeOptions;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "relationshipTableResponse$", {
                    get: function () {
                        return this._relationshipTableResponse$;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "statusOptions$", {
                    get: function () {
                        return this._statusOptions$;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "accessLevelOptions$", {
                    get: function () {
                        return this._accessLevelOptions$;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "relationshipOptions$", {
                    get: function () {
                        return this._relationshipOptions$;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationshipsTableComponent.prototype, "filters$", {
                    get: function () {
                        return this._filters$;
                    },
                    enumerable: true,
                    configurable: true
                });
                RelationshipsTableComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.nav.navObservable$.subscribe(function (relIds) { return _this.refreshContents(relIds); });
                };
                RelationshipsTableComponent.prototype.setPageSize = function (newSize) {
                    this._pageSize = newSize;
                    this.refreshContents(this._relIds);
                };
                RelationshipsTableComponent.prototype.refreshContents = function (relIds) {
                    var _this = this;
                    this._relIds = relIds;
                    this._isLoading = true;
                    var identityValue = this.routeParams.get('identityValue');
                    var identityResolver = this.routeParams.get('identityResolver');
                    var response = this.rest.getRelationshipTableData(identityResolver, identityValue, this._delegate, relIds, this._filters$.value, this._pageNo, this._pageSize)
                        .do(function () {
                        _this._isLoading = false;
                    });
                    this._relationshipTableResponse$ = response.map(function (r) { return r.table; });
                    this._relationshipOptions$ = response.map(function (r) { return r.relationshipOptions; });
                    this._accessLevelOptions$ = response.map(function (r) { return r.accessLevelOptions; });
                    this._statusOptions$ = response.map(function (r) { return r.statusValueOptions; });
                    return response;
                };
                RelationshipsTableComponent.prototype.navigateTo = function (relId) {
                    this.nav.navigateToRel(relId);
                };
                RelationshipsTableComponent.prototype.viewRelationship = function (relId) {
                    console.log("Todo: View relationship: " + relId);
                };
                __decorate([
                    core_4.Input(), 
                    __metadata('design:type', Boolean), 
                    __metadata('design:paramtypes', [Boolean])
                ], RelationshipsTableComponent.prototype, "delegate", null);
                RelationshipsTableComponent = __decorate([
                    core_4.Component({
                        selector: 'ram-relationships-table',
                        template: '<div class="row"><div class="col-md-12"><form [ngFormModel]="filters$"><table class="table table-hover"><thead><tr><th><h5>Name</h5></th><th><h5>Relationship</h5></th><th class="hidden-xs"><h5>Access Level</h5></th><th class="hidden-xs"><h5>Status</h5></th><th></th></tr><tr><th><input class="form-control" type="text" [ngFormControl]="filters$.controls[\'name\']" placeholder="Name ..."></th><th><select class="form-control" [ngFormControl]="filters$.controls[\'relationship\']"><option value="">(All)</option><option *ngFor="let item of relationshipOptions$ | async" value="{{item}}">{{item}}</option></select></th><th class="hidden-xs"><select [ngFormControl]="filters$.controls[\'accessLevel\']" class="form-control"><option value="">(All)</option><option *ngFor="let item of accessLevelOptions$ |async" value="{{item}}">{{item}}</option></select></th><th class="hidden-xs"><select class="form-control" [ngFormControl]="filters$.controls[\'status\']"><option value="">(All)</option><option *ngFor="let item of statusOptions$|async" value="{{item}}">{{item}}</option></select></th><th></th></tr></thead><tbody *ngIf="!isLoading"><tr *ngFor="let row of relationshipTableResponse$ | async"><td><a href="">{{row.name}}</a><small class="show" *ngIf="row.abn">ABN: {{row.abn}}</small></td><td>{{row.rel}}</td><td class="hidden-xs">{{row.access}}</td><td class="hidden-xs">{{row.status}}</td><td *ngIf="!delegate"><a class="btn btn-primary btn-sm" (click)="navigateTo(row.relId)">act as →</a></td><td *ngIf="delegate"><a class="btn btn-primary btn-sm" (click)="viewRelationship(row.relId)">View</a></td></tr></tbody><tbody *ngIf="isLoading"><tr><td colspan="5" class="text-center"><h3>Loading ...</h3></td></tr></tbody></table></form></div></div><div class="row" *ngIf="!isLoading"><div class="col-md-8"><div class="text-md-left text-xs-center"><nav><ul class="pagination"><li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">«</span></a></li><li [class.active]="pageNumber == 1"><a href="#">1</a></li><li><a href="#">2</a></li><li><a href="#">3</a></li><li><a href="#" aria-label="Next"><span aria-hidden="true">»</span></a></li></ul></nav></div></div><div class="col-md-4"><div class="pull-md-right text-xs-center"><div class="btn-group pagination" data-toggle="buttons"><label class="btn btn-primary" *ngFor="let pSizeValue of pageSizeOptions" [class.active]="pSizeValue == pageSize"><input type="radio" autocomplete="off" (ngModelChange)="setPageSize(pSizeValue)" name="{{pSizeValue}}"> {{pSizeValue}}</label></div></div></div></div>',
                        providers: [common_1.FORM_PROVIDERS],
                        directives: [common_1.FORM_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [ram_constants_service_1.RAMConstantsService, router_1.RouteParams, ram_nav_service_1.RAMNavService, ram_rest_service_1.RAMRestService])
                ], RelationshipsTableComponent);
                return RelationshipsTableComponent;
            }());
            exports_5("RelationshipsTableComponent", RelationshipsTableComponent);
        }
    }
});
System.register("frontend/typescript/components/nav-crumb/nav-crumb.component", ['angular2/core', "frontend/typescript/services/ram-nav.service", "frontend/typescript/services/ram-rest.service"], function(exports_6, context_6) {
    "use strict";
    var __moduleName = context_6 && context_6.id;
    var core_5, ram_nav_service_2, ram_rest_service_2;
    var NavCrumbComponent;
    return {
        setters:[
            function (core_5_1) {
                core_5 = core_5_1;
            },
            function (ram_nav_service_2_1) {
                ram_nav_service_2 = ram_nav_service_2_1;
            },
            function (ram_rest_service_2_1) {
                ram_rest_service_2 = ram_rest_service_2_1;
            }],
        execute: function() {
            NavCrumbComponent = (function () {
                function NavCrumbComponent(nav, rest) {
                    this.nav = nav;
                    this.rest = rest;
                }
                NavCrumbComponent.prototype.navigateTo = function (relId) {
                    this.nav.navigateToRel(relId);
                };
                NavCrumbComponent = __decorate([
                    core_5.Component({
                        selector: 'nav-crumb',
                        template: '<div class="page-header"><h3><span *ngFor="#rel of relChain$ | async"><a (click)="navigateTo(rel.id)"><strong>{{rel.name}}</strong></a> acting as</span> <span *ngIf="subjectUser$ | async"><strong>{{(subjectUser$ | async).name}}</strong> can act/authorised for</span></h3></div>'
                    }), 
                    __metadata('design:paramtypes', [ram_nav_service_2.RAMNavService, ram_rest_service_2.RAMRestService])
                ], NavCrumbComponent);
                return NavCrumbComponent;
            }());
            exports_6("NavCrumbComponent", NavCrumbComponent);
        }
    }
});
System.register("frontend/typescript/components/relationships/relationships.component", ['angular2/core', "frontend/typescript/components/relationships-table/relationships-table.component", "frontend/typescript/components/nav-crumb/nav-crumb.component"], function(exports_7, context_7) {
    "use strict";
    var __moduleName = context_7 && context_7.id;
    var core_6, relationships_table_component_1, nav_crumb_component_1;
    var RelationshipsComponent;
    return {
        setters:[
            function (core_6_1) {
                core_6 = core_6_1;
            },
            function (relationships_table_component_1_1) {
                relationships_table_component_1 = relationships_table_component_1_1;
            },
            function (nav_crumb_component_1_1) {
                nav_crumb_component_1 = nav_crumb_component_1_1;
            }],
        execute: function() {
            RelationshipsComponent = (function () {
                function RelationshipsComponent() {
                }
                RelationshipsComponent = __decorate([
                    core_6.Component({
                        selector: 'ram-relationships',
                        template: '<div class="col-lg-9 col-md-9 col-sm-8"><div class="page-header"><div class="row"><div class="pull-md-right col-md-5 col-lg-4 col-xs-12"><div class="btn-toolbar"><div class="row"><div class="col-sm-12"><button type="button" class="btn btn-sm btn-primary col-xs-12 col-sm-6">Add a relationship</button> <button type="button" class="btn btn-sm btn-primary col-xs-12 col-sm-6">Accept an invitation</button></div><div class="col-md-12 padding-btn-30 visible-xs visible-sm"><p></p></div></div></div></div><h2 class="col-sm-12 col-md-7 col-lg-8 col-xs-12">Relationships and authorisations</h2></div></div><nav-crumb></nav-crumb><p class="lead"></p><h4>You have access to the entries listed below. Select an entity to view the relationship or manage access. Find out more about <a href="">managing access</a>.</h4><p></p><div class="ram section"><ram-relationships-table [delegate]="false"></ram-relationships-table></div><div class="page-header"><h3>Who can act/authorised for <strong>Jennifer Maxims</strong></h3></div><p class="lead"></p><h4>The entities below have access to your entity. Select an entity to view the relationship or manage access. Find out more about <a href="">managing access</a>.</h4><p></p><div class="ram section"><div class="row"><div class="col-md-12"><ram-relationships-table [delegate]="true"></ram-relationships-table></div></div></div></div>',
                        directives: [relationships_table_component_1.RelationshipsTableComponent, nav_crumb_component_1.NavCrumbComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], RelationshipsComponent);
                return RelationshipsComponent;
            }());
            exports_7("RelationshipsComponent", RelationshipsComponent);
        }
    }
});
System.register("frontend/typescript/components/app/app.component", ['angular2/core', 'angular2/http', 'angular2/router', "frontend/typescript/services/ram-rest.service", "frontend/typescript/services/ram-nav.service", "frontend/typescript/services/ram-constants.service", "frontend/typescript/components/relationships/relationships.component", 'angular2/platform/common', 'ng2-bootstrap'], function(exports_8, context_8) {
    "use strict";
    var __moduleName = context_8 && context_8.id;
    var core_7, http_2, router_2, ram_rest_service_3, ram_nav_service_3, ram_constants_service_2, relationships_component_1, common_2, core_8;
    var AppComponent;
    return {
        setters:[
            function (core_7_1) {
                core_7 = core_7_1;
                core_8 = core_7_1;
            },
            function (http_2_1) {
                http_2 = http_2_1;
            },
            function (router_2_1) {
                router_2 = router_2_1;
            },
            function (ram_rest_service_3_1) {
                ram_rest_service_3 = ram_rest_service_3_1;
            },
            function (ram_nav_service_3_1) {
                ram_nav_service_3 = ram_nav_service_3_1;
            },
            function (ram_constants_service_2_1) {
                ram_constants_service_2 = ram_constants_service_2_1;
            },
            function (relationships_component_1_1) {
                relationships_component_1 = relationships_component_1_1;
            },
            function (common_2_1) {
                common_2 = common_2_1;
            },
            function (_1) {}],
        execute: function() {
            AppComponent = (function () {
                function AppComponent() {
                }
                AppComponent = __decorate([
                    core_7.Component({
                        selector: 'ram-app',
                        template: '<nav class="navbar navbar-default"><div class="container-fluid"><div class="navbar-header"><nav class="navbar navbar-default"><div class="container-fluid"><div class="navbar-header"><a class="navbar-brand" href="#"><img src="/images/commonwealth-trans-bw-full.gif"></a><h1 class="inline">Business Account</h1></div></div></nav></div><div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1"><ul class="nav navbar-nav navbar-right"><li><h4 class="navbar-text">Last logged in 11/10/2015 10:01 AM</h4></li><li class="dropdown"><h4 class="navbar-text"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Jennifer Maxims<span class="caret"></span></a></h4><ul class="dropdown-menu"><li><a href="#">Action</a></li><li><a href="#">Another action</a></li><li><a href="#">Something else here</a></li><li role="separator" class="divider"></li><li><a href="#">Separated link</a></li></ul></li></ul></div></div></nav><div class="container"><div class="row"><div class="col-lg-3 col-md-3 col-sm-4"><div class="list-group table-of-contents"><a class="list-group-item" href="">Home</a> <a class="list-group-item" href="">Inbox <span class="badge">4</span></a> <a class="list-group-item active" href="">Authorisation</a> <a class="list-group-item" href="">Business details</a> <a class="list-group-item" href="">Agency services</a> <a class="list-group-item" href="">Activity log</a> <a class="list-group-item" href="">Settings</a></div></div><router-outlet></router-outlet></div></div><footer class="footer"><div class="container"><div class="row"><div class="col-sm-6"><a class="col-xs-12">ABN Lookup</a> <a class="col-xs-12">Australian Business Licence and Information Service</a> <a class="col-xs-12">Australian Business Account</a> <a class="col-xs-12">Australian Business Register</a> <a class="col-xs-12">Australian Securities &amp; investment Commission</a></div><div class="col-sm-6"><a class="col-xs-12">Australian Taxation Office Lookup</a> <a class="col-xs-12">Business Consultation</a> <a class="col-xs-12">business.gov.au</a> <a class="col-xs-12">Register a new business</a> <a class="col-xs-12">Standard Business Reporting</a></div></div></div></footer>',
                        directives: [router_2.ROUTER_DIRECTIVES],
                        providers: [
                            http_2.HTTP_PROVIDERS,
                            router_2.ROUTER_PROVIDERS,
                            core_8.provide(common_2.LocationStrategy, { useClass: common_2.HashLocationStrategy }),
                            ram_rest_service_3.RAMRestService,
                            ram_nav_service_3.RAMNavService,
                            ram_constants_service_2.RAMConstantsService
                        ]
                    }),
                    router_2.RouteConfig([
                        {
                            path: '/relationships/:identityValue/:identityResolver',
                            name: 'Relationships',
                            component: relationships_component_1.RelationshipsComponent
                        }
                    ]), 
                    __metadata('design:paramtypes', [])
                ], AppComponent);
                return AppComponent;
            }());
            exports_8("AppComponent", AppComponent);
        }
    }
});
System.register("frontend/typescript/Boot", ['es6-shim', 'angular2/bundles/angular2-polyfills', 'rxjs/Rx', 'ng2-bootstrap', 'angular2/platform/browser', "frontend/typescript/components/app/app.component"], function(exports_9, context_9) {
    "use strict";
    var __moduleName = context_9 && context_9.id;
    var browser_1, app_component_1;
    return {
        setters:[
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(app_component_1.AppComponent, []).catch(function (err) { return console.error(err); });
        }
    }
});
System.register("frontend/typescript/components/four-o-four/four-o-four.component", ['angular2/core'], function(exports_10, context_10) {
    "use strict";
    var __moduleName = context_10 && context_10.id;
    var core_9;
    var FourOFourComponent;
    return {
        setters:[
            function (core_9_1) {
                core_9 = core_9_1;
            }],
        execute: function() {
            FourOFourComponent = (function () {
                function FourOFourComponent() {
                }
                FourOFourComponent = __decorate([
                    core_9.Component({
                        selector: 'ram-four-o-four',
                        template: '<h1>FourOFour.component.html</h1>'
                    }), 
                    __metadata('design:paramtypes', [])
                ], FourOFourComponent);
                return FourOFourComponent;
            }());
            exports_10("FourOFourComponent", FourOFourComponent);
        }
    }
});
System.register("commons/RamUtils", [], function(exports_11, context_11) {
    "use strict";
    var __moduleName = context_11 && context_11.id;
    var Helpers;
    return {
        setters:[],
        execute: function() {
            Helpers = (function () {
                function Helpers() {
                }
                Helpers.applyMixins = function (derivedCtor, baseCtors) {
                    baseCtors.forEach(function (baseCtor) {
                        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
                            derivedCtor.prototype[name] = baseCtor.prototype[name];
                        });
                    });
                };
                return Helpers;
            }());
            exports_11("Helpers", Helpers);
        }
    }
});

//# sourceMappingURL=app.js.map
