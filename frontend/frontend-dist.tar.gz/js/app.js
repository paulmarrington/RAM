System.register("commons/RamEnums", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AccessLevels, AuthorisationStatus;
    return {
        setters:[],
        execute: function() {
            (function (AccessLevels) {
                AccessLevels[AccessLevels["NoAccess"] = 0] = "NoAccess";
                AccessLevels[AccessLevels["Associate"] = 1] = "Associate";
                AccessLevels[AccessLevels["Universal"] = 2] = "Universal";
            })(AccessLevels || (AccessLevels = {}));
            exports_1("AccessLevels", AccessLevels);
            (function (AuthorisationStatus) {
                AuthorisationStatus[AuthorisationStatus["Active"] = 1] = "Active";
                AuthorisationStatus[AuthorisationStatus["NotActive"] = 0] = "NotActive";
            })(AuthorisationStatus || (AuthorisationStatus = {}));
            exports_1("AuthorisationStatus", AuthorisationStatus);
        }
    }
});
System.register("commons/RamAPI", [], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var ErrorResponse, ErrorResponseWithData, DataResponse, BusinessName, IndividualBusinessAuthorisation;
    return {
        setters:[],
        execute: function() {
            ErrorResponse = (function () {
                function ErrorResponse(errorCode, errorMessage) {
                    this.errorCode = errorCode;
                    this.errorMessage = errorMessage;
                    this.isError = true;
                }
                return ErrorResponse;
            }());
            exports_2("ErrorResponse", ErrorResponse);
            ErrorResponseWithData = (function () {
                function ErrorResponseWithData(data, errorCode, errorMessage) {
                    this.data = data;
                    this.errorCode = errorCode;
                    this.errorMessage = errorMessage;
                    this.isError = true;
                }
                return ErrorResponseWithData;
            }());
            exports_2("ErrorResponseWithData", ErrorResponseWithData);
            DataResponse = (function () {
                function DataResponse(data) {
                    this.data = data;
                    this.isError = false;
                }
                return DataResponse;
            }());
            exports_2("DataResponse", DataResponse);
            BusinessName = (function () {
                function BusinessName(name, abn) {
                    this.name = name;
                    this.abn = abn;
                }
                return BusinessName;
            }());
            exports_2("BusinessName", BusinessName);
            IndividualBusinessAuthorisation = (function () {
                function IndividualBusinessAuthorisation(businessName, abn, activeOn, authorisationStatus, accessLevel, expiresOn) {
                    this.businessName = businessName;
                    this.abn = abn;
                    this.activeOn = activeOn;
                    this.authorisationStatus = authorisationStatus;
                    this.accessLevel = accessLevel;
                    this.expiresOn = expiresOn;
                }
                return IndividualBusinessAuthorisation;
            }());
            exports_2("IndividualBusinessAuthorisation", IndividualBusinessAuthorisation);
        }
    }
});
System.register("commons/RamUtils", ["commons/RamEnums"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var enums;
    var Helpers;
    return {
        setters:[
            function (enums_1) {
                enums = enums_1;
            }],
        execute: function() {
            Helpers = (function () {
                function Helpers() {
                }
                Helpers.AuthorisationStatusNames = function (e) {
                    switch (e) {
                        case enums.AuthorisationStatus.Active:
                            return "Active";
                        case enums.AuthorisationStatus.NotActive:
                            return "Not Active";
                        default:
                            throw new Error("Unknow authorisation value " + e);
                    }
                };
                Helpers.AccessLevelNames = function (e) {
                    switch (e) {
                        case enums.AccessLevels.NoAccess:
                            return "No Access";
                        case enums.AccessLevels.Associate:
                            return "Associate";
                        case enums.AccessLevels.Universal:
                            return "Universal";
                        default:
                            throw new Error("Unknow accessLevel value " + e);
                    }
                };
                Helpers.applyMixins = function (derivedCtor, baseCtors) {
                    baseCtors.forEach(function (baseCtor) {
                        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
                            derivedCtor.prototype[name] = baseCtor.prototype[name];
                        });
                    });
                };
                return Helpers;
            }());
            exports_3("Helpers", Helpers);
        }
    }
});
System.register("frontend/typescript/api/IRamScope", [], function(exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    return {
        setters:[],
        execute: function() {
        }
    }
});
System.register("frontend/typescript/controllers/Layout.client.ctrl", [], function(exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var LayoutCtrl;
    return {
        setters:[],
        execute: function() {
            LayoutCtrl = (function () {
                function LayoutCtrl($scope, restAngualr) {
                    this.$scope = $scope;
                }
                LayoutCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return LayoutCtrl;
            }());
            exports_5("LayoutCtrl", LayoutCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/page1/Page1.client.ctrl", [], function(exports_6, context_6) {
    "use strict";
    var __moduleName = context_6 && context_6.id;
    var Page1Ctrl;
    return {
        setters:[],
        execute: function() {
            Page1Ctrl = (function () {
                function Page1Ctrl($scope, restAngualr) {
                    this.$scope = $scope;
                }
                Page1Ctrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return Page1Ctrl;
            }());
            exports_6("Page1Ctrl", Page1Ctrl);
        }
    }
});
System.register("frontend/typescript/controllers/page2/Page2.client.ctrl", [], function(exports_7, context_7) {
    "use strict";
    var __moduleName = context_7 && context_7.id;
    var Page2Ctrl;
    return {
        setters:[],
        execute: function() {
            Page2Ctrl = (function () {
                function Page2Ctrl($scope, restAngualr) {
                    this.$scope = $scope;
                }
                Page2Ctrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return Page2Ctrl;
            }());
            exports_7("Page2Ctrl", Page2Ctrl);
        }
    }
});
System.register("frontend/typescript/controllers/home/Home.client.ctrl", ["commons/RamUtils"], function(exports_8, context_8) {
    "use strict";
    var __moduleName = context_8 && context_8.id;
    var cUtils;
    var HomeCtrl;
    return {
        setters:[
            function (cUtils_1) {
                cUtils = cUtils_1;
            }],
        execute: function() {
            HomeCtrl = (function () {
                function HomeCtrl($scope, restNg) {
                    this.$scope = $scope;
                    $scope.helpers = cUtils.Helpers;
                    var relations = restNg.all("relations");
                    relations.one("123").getList().then(function (individual_business_authorisations) {
                        $scope.individual_business_authorisations = individual_business_authorisations;
                    });
                }
                HomeCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return HomeCtrl;
            }());
            exports_8("HomeCtrl", HomeCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/404/FourOFour.client.ctrl", [], function(exports_9, context_9) {
    "use strict";
    var __moduleName = context_9 && context_9.id;
    var FourOFourCtrl;
    return {
        setters:[],
        execute: function() {
            FourOFourCtrl = (function () {
                function FourOFourCtrl($scope) {
                    this.$scope = $scope;
                }
                FourOFourCtrl.$inject = [
                    "$scope"
                ];
                return FourOFourCtrl;
            }());
            exports_9("FourOFourCtrl", FourOFourCtrl);
        }
    }
});
System.register("frontend/typescript/app", ["frontend/typescript/controllers/Layout.client.ctrl", "frontend/typescript/controllers/page1/Page1.client.ctrl", "frontend/typescript/controllers/page2/Page2.client.ctrl", "frontend/typescript/controllers/home/Home.client.ctrl", "frontend/typescript/controllers/404/FourOFour.client.ctrl"], function(exports_10, context_10) {
    "use strict";
    var __moduleName = context_10 && context_10.id;
    var Layout_client_ctrl_1, Page1_client_ctrl_1, Page2_client_ctrl_1, Home_client_ctrl_1, FourOFour_client_ctrl_1;
    function Boot() {
        var app = angular.module("ram", [
            "ui.router",
            "angular-loading-bar",
            "restangular",
            "ui.bootstrap",
            "templates"
        ]);
        app.controller("LayoutCtrl", Layout_client_ctrl_1.LayoutCtrl)
            .controller("Page1Ctrl", Page1_client_ctrl_1.Page1Ctrl)
            .controller("Page2Ctrl", Page2_client_ctrl_1.Page2Ctrl)
            .controller("HomeCtrl", Home_client_ctrl_1.HomeCtrl)
            .controller("404Ctrl", FourOFour_client_ctrl_1.FourOFourCtrl);
        app.config(function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("/404");
            $stateProvider.state("layout", {
                templateProvider: function ($templateCache) { return $templateCache.get("layout.html"); },
                controller: "LayoutCtrl"
            }).state("layout.page1", {
                templateProvider: function ($templateCache) { return $templateCache.get("page1/index.html"); },
                controller: "Page1Ctrl",
                url: "/page1/"
            }).state("layout.page2", {
                templateProvider: function ($templateCache) { return $templateCache.get("page2/index.html"); },
                controller: "Page2Ctrl",
                url: "/page2/"
            }).state("layout.404", {
                templateProvider: function ($templateCache) { return $templateCache.get("404/index.html"); },
                controller: "404Ctrl",
                url: "/404"
            }).state("layout.home", {
                templateProvider: function ($templateCache) { return $templateCache.get("home/index.html"); },
                controller: "HomeCtrl",
                url: ""
            });
        });
        app.config(function (RestangularProvider) {
            RestangularProvider.setBaseUrl("/api");
            RestangularProvider.addResponseInterceptor(function (data, operation, model, url, response, deffered) {
                return data["data"];
            });
        });
        angular.element(document).ready(function () {
            angular.bootstrap(document, ["ram"]);
        });
    }
    exports_10("Boot", Boot);
    return {
        setters:[
            function (Layout_client_ctrl_1_1) {
                Layout_client_ctrl_1 = Layout_client_ctrl_1_1;
            },
            function (Page1_client_ctrl_1_1) {
                Page1_client_ctrl_1 = Page1_client_ctrl_1_1;
            },
            function (Page2_client_ctrl_1_1) {
                Page2_client_ctrl_1 = Page2_client_ctrl_1_1;
            },
            function (Home_client_ctrl_1_1) {
                Home_client_ctrl_1 = Home_client_ctrl_1_1;
            },
            function (FourOFour_client_ctrl_1_1) {
                FourOFour_client_ctrl_1 = FourOFour_client_ctrl_1_1;
            }],
        execute: function() {
        }
    }
});
System.register("frontend/typescript/Boot", ["jquery", "angular", "angular-ui-router", "angular-loading-bar", "lodash", "restangular", "angular-bootstrap", "js/templates", "frontend/typescript/app"], function(exports_11, context_11) {
    "use strict";
    var __moduleName = context_11 && context_11.id;
    var App_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (_6) {},
            function (_7) {},
            function (_8) {},
            function (App_1_1) {
                App_1 = App_1_1;
            }],
        execute: function() {
            App_1.Boot();
        }
    }
});

//# sourceMappingURL=app.js.map
