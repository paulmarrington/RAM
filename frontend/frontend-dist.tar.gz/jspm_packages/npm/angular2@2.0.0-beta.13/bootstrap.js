/* */ 
"format cjs";
'use strict';/**
 * See {@link bootstrap} for more information.
 * @deprecated
 */
var browser_1 = require('angular2/platform/browser');
exports.bootstrap = browser_1.bootstrap;
var angular_entrypoint_1 = require('angular2/src/core/angular_entrypoint');
exports.AngularEntrypoint = angular_entrypoint_1.AngularEntrypoint;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9vdHN0cmFwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYW5ndWxhcjIvYm9vdHN0cmFwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUNILHdCQUF3QiwyQkFBMkIsQ0FBQztBQUE1Qyx3Q0FBNEM7QUFDcEQsbUNBQWdDLHNDQUFzQyxDQUFDO0FBQS9ELG1FQUErRCIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogU2VlIHtAbGluayBib290c3RyYXB9IGZvciBtb3JlIGluZm9ybWF0aW9uLlxuICogQGRlcHJlY2F0ZWRcbiAqL1xuZXhwb3J0IHtib290c3RyYXB9IGZyb20gJ2FuZ3VsYXIyL3BsYXRmb3JtL2Jyb3dzZXInO1xuZXhwb3J0IHtBbmd1bGFyRW50cnlwb2ludH0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvYW5ndWxhcl9lbnRyeXBvaW50JztcbiJdfQ==