/* */ 
"format cjs";
'use strict';function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
// Test library and utilities for internal use.
__export(require('./src/testing/testing_internal'));
__export(require('./src/testing/test_component_builder'));
__export(require('./src/testing/test_injector'));
__export(require('./src/testing/fake_async'));
__export(require('./src/testing/utils'));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdGluZ19pbnRlcm5hbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0NBQStDO0FBQy9DLGlCQUFjLGdDQUFnQyxDQUFDLEVBQUE7QUFDL0MsaUJBQWMsc0NBQXNDLENBQUMsRUFBQTtBQUNyRCxpQkFBYyw2QkFBNkIsQ0FBQyxFQUFBO0FBQzVDLGlCQUFjLDBCQUEwQixDQUFDLEVBQUE7QUFDekMsaUJBQWMscUJBQXFCLENBQUMsRUFBQSIsInNvdXJjZXNDb250ZW50IjpbIi8vIFRlc3QgbGlicmFyeSBhbmQgdXRpbGl0aWVzIGZvciBpbnRlcm5hbCB1c2UuXG5leHBvcnQgKiBmcm9tICcuL3NyYy90ZXN0aW5nL3Rlc3RpbmdfaW50ZXJuYWwnO1xuZXhwb3J0ICogZnJvbSAnLi9zcmMvdGVzdGluZy90ZXN0X2NvbXBvbmVudF9idWlsZGVyJztcbmV4cG9ydCAqIGZyb20gJy4vc3JjL3Rlc3RpbmcvdGVzdF9pbmplY3Rvcic7XG5leHBvcnQgKiBmcm9tICcuL3NyYy90ZXN0aW5nL2Zha2VfYXN5bmMnO1xuZXhwb3J0ICogZnJvbSAnLi9zcmMvdGVzdGluZy91dGlscyc7XG4iXX0=