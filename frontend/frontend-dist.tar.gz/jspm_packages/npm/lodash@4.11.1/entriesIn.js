/* */ 
module.exports = require('./toPairsIn');
