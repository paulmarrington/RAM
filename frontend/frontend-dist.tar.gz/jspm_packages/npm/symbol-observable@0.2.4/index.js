/* */ 
'use strict';
module.exports = require('./ponyfill')(global || window || this);
