define(["npm:moment@2.12.0/moment.js"], function(main) {
  return main;
});