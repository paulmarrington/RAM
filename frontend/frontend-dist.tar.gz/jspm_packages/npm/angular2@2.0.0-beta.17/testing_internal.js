/* */ 
"format cjs";
'use strict';"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
// Test library and utilities for internal use.
__export(require('./src/testing/testing_internal'));
__export(require('./src/testing/test_component_builder'));
__export(require('./src/testing/test_injector'));
__export(require('./src/testing/fake_async'));
__export(require('./src/testing/utils'));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdGluZ19pbnRlcm5hbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtdHNRdXFqdkYudG1wL2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLCtDQUErQztBQUMvQyxpQkFBYyxnQ0FBZ0MsQ0FBQyxFQUFBO0FBQy9DLGlCQUFjLHNDQUFzQyxDQUFDLEVBQUE7QUFDckQsaUJBQWMsNkJBQTZCLENBQUMsRUFBQTtBQUM1QyxpQkFBYywwQkFBMEIsQ0FBQyxFQUFBO0FBQ3pDLGlCQUFjLHFCQUFxQixDQUFDLEVBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUZXN0IGxpYnJhcnkgYW5kIHV0aWxpdGllcyBmb3IgaW50ZXJuYWwgdXNlLlxuZXhwb3J0ICogZnJvbSAnLi9zcmMvdGVzdGluZy90ZXN0aW5nX2ludGVybmFsJztcbmV4cG9ydCAqIGZyb20gJy4vc3JjL3Rlc3RpbmcvdGVzdF9jb21wb25lbnRfYnVpbGRlcic7XG5leHBvcnQgKiBmcm9tICcuL3NyYy90ZXN0aW5nL3Rlc3RfaW5qZWN0b3InO1xuZXhwb3J0ICogZnJvbSAnLi9zcmMvdGVzdGluZy9mYWtlX2FzeW5jJztcbmV4cG9ydCAqIGZyb20gJy4vc3JjL3Rlc3RpbmcvdXRpbHMnO1xuIl19