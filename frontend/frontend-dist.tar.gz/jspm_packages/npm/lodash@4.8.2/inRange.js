/* */ 
var baseInRange = require('./_baseInRange'),
    toNumber = require('./toNumber');
function inRange(number, start, end) {
  start = toNumber(start) || 0;
  if (end === undefined) {
    end = start;
    start = 0;
  } else {
    end = toNumber(end) || 0;
  }
  number = toNumber(number);
  return baseInRange(number, start, end);
}
module.exports = inRange;
