/* */ 
module.exports = require('./forEachRight');
