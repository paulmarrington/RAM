/* */ 
module.exports = require('./assignIn');
