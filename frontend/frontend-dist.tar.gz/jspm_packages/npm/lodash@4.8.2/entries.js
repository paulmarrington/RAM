/* */ 
module.exports = require('./toPairs');
