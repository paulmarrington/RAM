/* */ 
"format global";
require('./angular');
module.exports = angular;
