/* */ 
var baseEach = require('./_baseEach');
function baseEvery(collection, predicate) {
  var result = true;
  baseEach(collection, function(value, index, collection) {
    result = !!predicate(value, index, collection);
    return result;
  });
  return result;
}
module.exports = baseEvery;
