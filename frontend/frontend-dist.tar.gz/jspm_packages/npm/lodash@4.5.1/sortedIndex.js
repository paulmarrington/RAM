/* */ 
var baseSortedIndex = require('./_baseSortedIndex');
function sortedIndex(array, value) {
  return baseSortedIndex(array, value);
}
module.exports = sortedIndex;
