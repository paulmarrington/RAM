/* */ 
var createCaseFirst = require('./_createCaseFirst');
var upperFirst = createCaseFirst('toUpperCase');
module.exports = upperFirst;
