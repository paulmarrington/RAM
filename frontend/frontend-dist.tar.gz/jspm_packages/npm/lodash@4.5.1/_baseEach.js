/* */ 
var baseForOwn = require('./_baseForOwn'),
    createBaseEach = require('./_createBaseEach');
var baseEach = createBaseEach(baseForOwn);
module.exports = baseEach;
