/* */ 
var arrayMap = require('./_arrayMap'),
    createOver = require('./_createOver');
var over = createOver(arrayMap);
module.exports = over;
