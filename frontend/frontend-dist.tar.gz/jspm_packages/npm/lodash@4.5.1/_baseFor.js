/* */ 
var createBaseFor = require('./_createBaseFor');
var baseFor = createBaseFor();
module.exports = baseFor;
