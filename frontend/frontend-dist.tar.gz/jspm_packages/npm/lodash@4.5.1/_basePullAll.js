/* */ 
var basePullAllBy = require('./_basePullAllBy');
function basePullAll(array, values) {
  return basePullAllBy(array, values);
}
module.exports = basePullAll;
