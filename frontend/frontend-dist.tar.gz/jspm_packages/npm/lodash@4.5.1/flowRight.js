/* */ 
var createFlow = require('./_createFlow');
var flowRight = createFlow(true);
module.exports = flowRight;
