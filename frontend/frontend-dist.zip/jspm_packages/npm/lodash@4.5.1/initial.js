/* */ 
var dropRight = require('./dropRight');
function initial(array) {
  return dropRight(array, 1);
}
module.exports = initial;
