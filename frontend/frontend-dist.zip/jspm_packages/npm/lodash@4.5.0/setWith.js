/* */ 
var baseSet = require('./_baseSet');
function setWith(object, path, value, customizer) {
  customizer = typeof customizer == 'function' ? customizer : undefined;
  return object == null ? object : baseSet(object, path, value, customizer);
}
module.exports = setWith;
