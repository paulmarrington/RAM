/* */ 
var createRound = require('./_createRound');
var ceil = createRound('ceil');
module.exports = ceil;
