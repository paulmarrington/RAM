/* */ 
var arrayEvery = require('./_arrayEvery'),
    createOver = require('./_createOver');
var overEvery = createOver(arrayEvery);
module.exports = overEvery;
