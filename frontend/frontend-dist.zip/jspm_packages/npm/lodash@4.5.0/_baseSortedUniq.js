/* */ 
var baseSortedUniqBy = require('./_baseSortedUniqBy');
function baseSortedUniq(array) {
  return baseSortedUniqBy(array);
}
module.exports = baseSortedUniq;
