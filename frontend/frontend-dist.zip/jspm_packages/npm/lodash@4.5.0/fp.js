/* */ 
var _ = require('./lodash').runInContext();
module.exports = require('./fp/convert')(_);
