/* */ 
var arraySome = require('./_arraySome'),
    createOver = require('./_createOver');
var overSome = createOver(arraySome);
module.exports = overSome;
