/* */ 
var baseClone = require('./_baseClone');
function clone(value) {
  return baseClone(value);
}
module.exports = clone;
