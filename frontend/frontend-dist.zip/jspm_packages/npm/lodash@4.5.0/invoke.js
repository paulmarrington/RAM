/* */ 
var baseInvoke = require('./_baseInvoke'),
    rest = require('./rest');
var invoke = rest(baseInvoke);
module.exports = invoke;
