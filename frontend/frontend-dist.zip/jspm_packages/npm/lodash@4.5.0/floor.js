/* */ 
var createRound = require('./_createRound');
var floor = createRound('floor');
module.exports = floor;
