define(["npm:jquery@2.2.0/dist/jquery.js"], function(main) {
  return main;
});