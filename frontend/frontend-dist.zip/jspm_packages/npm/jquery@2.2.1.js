define(["npm:jquery@2.2.1/dist/jquery.js"], function(main) {
  return main;
});