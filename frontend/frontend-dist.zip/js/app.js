var ram;
(function (ram) {
    var Helpers = (function () {
        function Helpers() {
        }
        Helpers.AuthorisationStatusNames = function (e) {
            switch (e) {
                case ram.AuthorisationStatus.Active:
                    return "Active";
                case ram.AuthorisationStatus.NotActive:
                    return "Not Active";
                default:
                    throw new Error("Unknow authorisation value " + e);
            }
        };
        Helpers.AccessLevelNames = function (e) {
            switch (e) {
                case ram.AccessLevels.NoAccess:
                    return "No Access";
                case ram.AccessLevels.Associate:
                    return "Associate";
                case ram.AccessLevels.Universal:
                    return "Universal";
                default:
                    throw new Error("Unknow accessLevel value " + e);
            }
        };
        return Helpers;
    }());
    ram.Helpers = Helpers;
    var IndividualBusinessAuthorisation = (function () {
        function IndividualBusinessAuthorisation(businessName, abn, activeOn, authorisationStatus, accessLevel, expiresOn) {
            this.businessName = businessName;
            this.abn = abn;
            this.activeOn = activeOn;
            this.authorisationStatus = authorisationStatus;
            this.accessLevel = accessLevel;
            this.expiresOn = expiresOn;
        }
        return IndividualBusinessAuthorisation;
    }());
    ram.IndividualBusinessAuthorisation = IndividualBusinessAuthorisation;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var LayoutCtrl = (function () {
        function LayoutCtrl($scope) {
            this.$scope = $scope;
        }
        LayoutCtrl.$inject = [
            "$scope"
        ];
        return LayoutCtrl;
    }());
    ram.LayoutCtrl = LayoutCtrl;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var Page1Ctrl = (function () {
        function Page1Ctrl($scope) {
            this.$scope = $scope;
        }
        Page1Ctrl.$inject = [
            "$scope"
        ];
        return Page1Ctrl;
    }());
    ram.Page1Ctrl = Page1Ctrl;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var Page2Ctrl = (function () {
        function Page2Ctrl($scope) {
            this.$scope = $scope;
        }
        Page2Ctrl.$inject = [
            "$scope"
        ];
        return Page2Ctrl;
    }());
    ram.Page2Ctrl = Page2Ctrl;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var HomeCtrl = (function () {
        function HomeCtrl($scope) {
            this.$scope = $scope;
            $scope.helpers = ram.Helpers;
            $scope.individual_business_authorisations = [
                new ram.IndividualBusinessAuthorisation("Ted's Group", "22 2222 2222 22", new Date(), ram.AuthorisationStatus.Active, ram.AccessLevels.Associate),
                new ram.IndividualBusinessAuthorisation("Ali's Group", "33 3333 3333 33", new Date(), ram.AuthorisationStatus.Active, ram.AccessLevels.Associate),
            ];
        }
        HomeCtrl.$inject = [
            "$scope"
        ];
        return HomeCtrl;
    }());
    ram.HomeCtrl = HomeCtrl;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var FourOFourCtrl = (function () {
        function FourOFourCtrl($scope) {
            this.$scope = $scope;
        }
        FourOFourCtrl.$inject = [
            "$scope"
        ];
        return FourOFourCtrl;
    }());
    ram.FourOFourCtrl = FourOFourCtrl;
})(ram || (ram = {}));
var ram;
(function (ram) {
    (function (AccessLevels) {
        AccessLevels[AccessLevels["NoAccess"] = 0] = "NoAccess";
        AccessLevels[AccessLevels["Associate"] = 1] = "Associate";
        AccessLevels[AccessLevels["Universal"] = 2] = "Universal";
    })(ram.AccessLevels || (ram.AccessLevels = {}));
    var AccessLevels = ram.AccessLevels;
    ;
    (function (AuthorisationStatus) {
        AuthorisationStatus[AuthorisationStatus["Active"] = 1] = "Active";
        AuthorisationStatus[AuthorisationStatus["NotActive"] = 0] = "NotActive";
    })(ram.AuthorisationStatus || (ram.AuthorisationStatus = {}));
    var AuthorisationStatus = ram.AuthorisationStatus;
    ;
})(ram || (ram = {}));
var ram;
(function (ram) {
    var app = angular.module("ram", [
        "ui.router",
        "angular-loading-bar",
        "angular.filter",
        "restangular",
        "ui.bootstrap",
        "templates"
    ]);
    app.controller("LayoutCtrl", ram.LayoutCtrl)
        .controller("Page1Ctrl", ram.Page1Ctrl)
        .controller("Page2Ctrl", ram.Page2Ctrl)
        .controller("HomeCtrl", ram.HomeCtrl)
        .controller("404Ctrl", ram.FourOFourCtrl);
    app.config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise("/404");
        $stateProvider.state("layout", {
            templateProvider: function ($templateCache) { return $templateCache.get("layout.html"); },
            controller: "LayoutCtrl"
        }).state("layout.page1", {
            templateProvider: function ($templateCache) { return $templateCache.get("page1/index.html"); },
            controller: "Page1Ctrl",
            url: "/page1/"
        }).state("layout.page2", {
            templateProvider: function ($templateCache) { return $templateCache.get("page2/index.html"); },
            controller: "Page2Ctrl",
            url: "/page2/"
        }).state("layout.404", {
            templateProvider: function ($templateCache) { return $templateCache.get("404/index.html"); },
            controller: "404Ctrl",
            url: "/404"
        }).state("layout.home", {
            templateProvider: function ($templateCache) { return $templateCache.get("home/index.html"); },
            controller: "HomeCtrl",
            url: ""
        });
    });
})(ram || (ram = {}));

//# sourceMappingURL=app.js.map
