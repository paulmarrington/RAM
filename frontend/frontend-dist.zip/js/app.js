System.register("commons/RamEnums", [], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AccessLevels, AuthorisationStatus;
    return {
        setters:[],
        execute: function() {
            (function (AccessLevels) {
                AccessLevels[AccessLevels["NoAccess"] = 0] = "NoAccess";
                AccessLevels[AccessLevels["Associate"] = 1] = "Associate";
                AccessLevels[AccessLevels["Universal"] = 2] = "Universal";
            })(AccessLevels || (AccessLevels = {}));
            exports_1("AccessLevels", AccessLevels);
            (function (AuthorisationStatus) {
                AuthorisationStatus[AuthorisationStatus["Active"] = 1] = "Active";
                AuthorisationStatus[AuthorisationStatus["NotActive"] = 0] = "NotActive";
            })(AuthorisationStatus || (AuthorisationStatus = {}));
            exports_1("AuthorisationStatus", AuthorisationStatus);
        }
    }
});
System.register("commons/RamAPI", [], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var ErrorResponse, ErrorResponseWithData, DataResponse, BusinessName, IndividualBusinessAuthorisation;
    return {
        setters:[],
        execute: function() {
            ErrorResponse = (function () {
                function ErrorResponse(errorCode, errorMessage) {
                    this.errorCode = errorCode;
                    this.errorMessage = errorMessage;
                    this.isError = true;
                }
                return ErrorResponse;
            }());
            exports_2("ErrorResponse", ErrorResponse);
            ErrorResponseWithData = (function () {
                function ErrorResponseWithData(data, errorCode, errorMessage) {
                    this.data = data;
                    this.errorCode = errorCode;
                    this.errorMessage = errorMessage;
                    this.isError = true;
                }
                return ErrorResponseWithData;
            }());
            exports_2("ErrorResponseWithData", ErrorResponseWithData);
            DataResponse = (function () {
                function DataResponse(data) {
                    this.data = data;
                    this.isError = false;
                }
                return DataResponse;
            }());
            exports_2("DataResponse", DataResponse);
            BusinessName = (function () {
                function BusinessName(name, abn) {
                    this.name = name;
                    this.abn = abn;
                }
                return BusinessName;
            }());
            exports_2("BusinessName", BusinessName);
            IndividualBusinessAuthorisation = (function () {
                function IndividualBusinessAuthorisation(businessName, abn, activeOn, authorisationStatus, accessLevel, expiresOn) {
                    this.businessName = businessName;
                    this.abn = abn;
                    this.activeOn = activeOn;
                    this.authorisationStatus = authorisationStatus;
                    this.accessLevel = accessLevel;
                    this.expiresOn = expiresOn;
                }
                return IndividualBusinessAuthorisation;
            }());
            exports_2("IndividualBusinessAuthorisation", IndividualBusinessAuthorisation);
        }
    }
});
System.register("commons/RamUtils", ["commons/RamEnums"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var enums;
    var Helpers;
    return {
        setters:[
            function (enums_1) {
                enums = enums_1;
            }],
        execute: function() {
            Helpers = (function () {
                function Helpers() {
                }
                Helpers.AuthorisationStatusNames = function (e) {
                    switch (e) {
                        case enums.AuthorisationStatus.Active:
                            return "Active";
                        case enums.AuthorisationStatus.NotActive:
                            return "Not Active";
                        default:
                            throw new Error("Unknow authorisation value " + e);
                    }
                };
                Helpers.AccessLevelNames = function (e) {
                    switch (e) {
                        case enums.AccessLevels.NoAccess:
                            return "No Access";
                        case enums.AccessLevels.Associate:
                            return "Associate";
                        case enums.AccessLevels.Universal:
                            return "Universal";
                        default:
                            throw new Error("Unknow accessLevel value " + e);
                    }
                };
                Helpers.applyMixins = function (derivedCtor, baseCtors) {
                    baseCtors.forEach(function (baseCtor) {
                        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
                            derivedCtor.prototype[name] = baseCtor.prototype[name];
                        });
                    });
                };
                return Helpers;
            }());
            exports_3("Helpers", Helpers);
        }
    }
});
System.register("frontend/typescript/api/IRamScope", [], function(exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    return {
        setters:[],
        execute: function() {
        }
    }
});
System.register("frontend/typescript/controllers/Layout.client.ctrl", [], function(exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var LayoutCtrl;
    return {
        setters:[],
        execute: function() {
            LayoutCtrl = (function () {
                function LayoutCtrl($scope, restAngualr) {
                    this.$scope = $scope;
                }
                LayoutCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return LayoutCtrl;
            }());
            exports_5("LayoutCtrl", LayoutCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/partyList/PartyList.client.ctrl", [], function(exports_6, context_6) {
    "use strict";
    var __moduleName = context_6 && context_6.id;
    var PartyListCtrl;
    return {
        setters:[],
        execute: function() {
            PartyListCtrl = (function () {
                function PartyListCtrl($scope, restAngualr) {
                    this.$scope = $scope;
                }
                PartyListCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return PartyListCtrl;
            }());
            exports_6("PartyListCtrl", PartyListCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/partyRelations/PartyRelations.client.ctrl", [], function(exports_7, context_7) {
    "use strict";
    var __moduleName = context_7 && context_7.id;
    var PartyRelationsCtrl;
    return {
        setters:[],
        execute: function() {
            PartyRelationsCtrl = (function () {
                function PartyRelationsCtrl($scope, restAngualr) {
                    this.$scope = $scope;
                    $scope.businessNames = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Dakota", "North Carolina", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"];
                }
                PartyRelationsCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return PartyRelationsCtrl;
            }());
            exports_7("PartyRelationsCtrl", PartyRelationsCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/home/Home.client.ctrl", ["commons/RamUtils"], function(exports_8, context_8) {
    "use strict";
    var __moduleName = context_8 && context_8.id;
    var cUtils;
    var HomeCtrl;
    return {
        setters:[
            function (cUtils_1) {
                cUtils = cUtils_1;
            }],
        execute: function() {
            HomeCtrl = (function () {
                function HomeCtrl($scope, restNg) {
                    this.$scope = $scope;
                    var categories = {
                        category_groups: [{ "name": "category" }, { name: "category" }, { name: "category" }],
                        categories: [{ name: "Business Representative", category: 1 },
                            { name: "Online Service provider", category: 1 },
                            { name: "Insolvency practitioner", category: 1 },
                            { name: "Trusted Intermediary", category: 1 },
                            { name: "Doctor Patient", category: 1 },
                            { name: "Nominated Entity", category: 1 },
                            { name: "Power of Attorney (Voluntary)", category: 2 },
                            { name: "Power of Attorney (Involuntary)", category: 2 },
                            { name: "Executor of deceased estate", category: 3 },
                            { name: "Institution to student", category: 3 },
                            { name: "Training organisations (RTO)", category: 3 },
                            { name: "Parent - Child", category: 1 },
                            { name: "Employment Agents", category: 1 }]
                    };
                    $scope.helpers = cUtils.Helpers;
                    var relations = restNg.all("relations");
                    relations.one("123").getList().then(function (individual_business_authorisations) {
                        $scope.individual_business_authorisations = individual_business_authorisations;
                    });
                }
                HomeCtrl.$inject = [
                    "$scope",
                    "Restangular"
                ];
                return HomeCtrl;
            }());
            exports_8("HomeCtrl", HomeCtrl);
        }
    }
});
System.register("frontend/typescript/controllers/404/FourOFour.client.ctrl", [], function(exports_9, context_9) {
    "use strict";
    var __moduleName = context_9 && context_9.id;
    var FourOFourCtrl;
    return {
        setters:[],
        execute: function() {
            FourOFourCtrl = (function () {
                function FourOFourCtrl($scope) {
                    this.$scope = $scope;
                }
                FourOFourCtrl.$inject = [
                    "$scope"
                ];
                return FourOFourCtrl;
            }());
            exports_9("FourOFourCtrl", FourOFourCtrl);
        }
    }
});
System.register("frontend/typescript/widgets/RelationshipTable.widget", [], function(exports_10, context_10) {
    "use strict";
    var __moduleName = context_10 && context_10.id;
    var RelationshipTableWidget, RelationshipTableWidgetController;
    return {
        setters:[],
        execute: function() {
            RelationshipTableWidget = (function () {
                function RelationshipTableWidget($templateCache) {
                    this.$templateCache = $templateCache;
                    this.restrict = "E";
                    this.controller = RelationshipTableWidgetController;
                    this.controllerAs = "Ctrl";
                    this.scope = {
                        "myTitle": "=",
                    };
                    this.link = function (scope, element, attrs) {
                    };
                }
                RelationshipTableWidget.prototype.template = function () {
                    return this.$templateCache.get("widgets/RelationshipTable.widget.html");
                };
                RelationshipTableWidget.Factory = function () {
                    var directive = function ($templateCache) {
                        return new RelationshipTableWidget($templateCache);
                    };
                    directive["$inject"] = ["$templateCache"];
                    return directive;
                };
                return RelationshipTableWidget;
            }());
            exports_10("RelationshipTableWidget", RelationshipTableWidget);
            RelationshipTableWidgetController = (function () {
                function RelationshipTableWidgetController(scope, element, attr) {
                    this.scope = scope;
                    this.element = element;
                    this.attr = attr;
                }
                RelationshipTableWidgetController.prototype.handleAction = function () {
                    this.scope.myTitle = "clicked";
                };
                RelationshipTableWidgetController.$inject = ["$scope", "$element", "$attrs"];
                return RelationshipTableWidgetController;
            }());
            exports_10("RelationshipTableWidgetController", RelationshipTableWidgetController);
        }
    }
});
System.register("frontend/typescript/app", ["frontend/typescript/controllers/Layout.client.ctrl", "frontend/typescript/controllers/partyList/PartyList.client.ctrl", "frontend/typescript/controllers/partyRelations/PartyRelations.client.ctrl", "frontend/typescript/controllers/home/Home.client.ctrl", "frontend/typescript/controllers/404/FourOFour.client.ctrl", "frontend/typescript/widgets/RelationshipTable.widget"], function(exports_11, context_11) {
    "use strict";
    var __moduleName = context_11 && context_11.id;
    var Layout_client_ctrl_1, PartyList_client_ctrl_1, PartyRelations_client_ctrl_1, Home_client_ctrl_1, FourOFour_client_ctrl_1, RelationshipTable_widget_1;
    function Boot() {
        var app = angular.module("ram", [
            "ui.router",
            "angular-loading-bar",
            "restangular",
            "ui.bootstrap",
            "templates"
        ]);
        app.controller("LayoutCtrl", Layout_client_ctrl_1.LayoutCtrl)
            .controller("PartyListCtrl", PartyList_client_ctrl_1.PartyListCtrl)
            .controller("PartyRelationsCtrl", PartyRelations_client_ctrl_1.PartyRelationsCtrl)
            .controller("HomeCtrl", Home_client_ctrl_1.HomeCtrl)
            .controller("404Ctrl", FourOFour_client_ctrl_1.FourOFourCtrl);
        app.directive("relationshipTable", RelationshipTable_widget_1.RelationshipTableWidget.Factory());
        app.config(function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("/404");
            $stateProvider.state("layout", {
                templateProvider: function ($templateCache) { return $templateCache.get("layout.html"); },
                controller: "LayoutCtrl"
            }).state("layout.partyList", {
                templateProvider: function ($templateCache) { return $templateCache.get("partyList/index.html"); },
                controller: "PartyListCtrl",
                url: "/party/:party"
            }).state("layout.partyRelations", {
                templateProvider: function ($templateCache) { return $templateCache.get("partyRelations/index.html"); },
                controller: "PartyRelationsCtrl",
                url: "/party/:party/relations"
            }).state("layout.404", {
                templateProvider: function ($templateCache) { return $templateCache.get("404/index.html"); },
                controller: "404Ctrl",
                url: "/404"
            }).state("layout.home", {
                templateProvider: function ($templateCache) { return $templateCache.get("home/index.html"); },
                controller: "HomeCtrl",
                url: ""
            });
        });
        app.config(function (RestangularProvider) {
            RestangularProvider.setBaseUrl("/api");
            RestangularProvider.addResponseInterceptor(function (data, operation, model, url, response, deffered) {
                return data["data"];
            });
        });
        angular.element(document).ready(function () {
            angular.bootstrap(document, ["ram"]);
        });
    }
    exports_11("Boot", Boot);
    return {
        setters:[
            function (Layout_client_ctrl_1_1) {
                Layout_client_ctrl_1 = Layout_client_ctrl_1_1;
            },
            function (PartyList_client_ctrl_1_1) {
                PartyList_client_ctrl_1 = PartyList_client_ctrl_1_1;
            },
            function (PartyRelations_client_ctrl_1_1) {
                PartyRelations_client_ctrl_1 = PartyRelations_client_ctrl_1_1;
            },
            function (Home_client_ctrl_1_1) {
                Home_client_ctrl_1 = Home_client_ctrl_1_1;
            },
            function (FourOFour_client_ctrl_1_1) {
                FourOFour_client_ctrl_1 = FourOFour_client_ctrl_1_1;
            },
            function (RelationshipTable_widget_1_1) {
                RelationshipTable_widget_1 = RelationshipTable_widget_1_1;
            }],
        execute: function() {
        }
    }
});
System.register("frontend/typescript/Boot", ["jquery", "angular", "angular-ui-router", "angular-loading-bar", "lodash", "restangular", "angular-bootstrap", "js/templates", "frontend/typescript/app"], function(exports_12, context_12) {
    "use strict";
    var __moduleName = context_12 && context_12.id;
    var App_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (_6) {},
            function (_7) {},
            function (_8) {},
            function (App_1_1) {
                App_1 = App_1_1;
            }],
        execute: function() {
            App_1.Boot();
        }
    }
});

//# sourceMappingURL=app.js.map
