"use strict";
(function (AccessLevels) {
    AccessLevels[AccessLevels["NoAccess"] = 0] = "NoAccess";
    AccessLevels[AccessLevels["Associate"] = 1] = "Associate";
    AccessLevels[AccessLevels["Universal"] = 2] = "Universal";
})(exports.AccessLevels || (exports.AccessLevels = {}));
var AccessLevels = exports.AccessLevels;
(function (AuthorisationStatus) {
    AuthorisationStatus[AuthorisationStatus["Active"] = 1] = "Active";
    AuthorisationStatus[AuthorisationStatus["NotActive"] = 0] = "NotActive";
})(exports.AuthorisationStatus || (exports.AuthorisationStatus = {}));
var AuthorisationStatus = exports.AuthorisationStatus;

//# sourceMappingURL=RamEnums.js.map
