"use strict";
const enums = require("./RamEnums");
class Helpers {
    static AuthorisationStatusNames(e) {
        switch (e) {
            case enums.AuthorisationStatus.Active:
                return "Active";
            case enums.AuthorisationStatus.NotActive:
                return "Not Active";
            default:
                throw new Error(`Unknow authorisation value ${e}`);
        }
    }
    static AccessLevelNames(e) {
        switch (e) {
            case enums.AccessLevels.NoAccess:
                return "No Access";
            case enums.AccessLevels.Associate:
                return "Associate";
            case enums.AccessLevels.Universal:
                return "Universal";
            default:
                throw new Error(`Unknow accessLevel value ${e}`);
        }
    }
    static applyMixins(derivedCtor, baseCtors) {
        baseCtors.forEach(baseCtor => {
            Object.getOwnPropertyNames(baseCtor.prototype).forEach(name => {
                derivedCtor.prototype[name] = baseCtor.prototype[name];
            });
        });
    }
}
exports.Helpers = Helpers;

//# sourceMappingURL=RamUtils.js.map
