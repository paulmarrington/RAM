"use strict";
class Helpers {
    static applyMixins(derivedCtor, baseCtors) {
        baseCtors.forEach(baseCtor => {
            Object.getOwnPropertyNames(baseCtor.prototype).forEach(name => {
                derivedCtor.prototype[name] = baseCtor.prototype[name];
            });
        });
    }
}
exports.Helpers = Helpers;

//# sourceMappingURL=RamUtils.js.map
