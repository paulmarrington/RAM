"use strict";
exports.RelationshipType = {
    business: "Business",
    online: "Online Service Provider"
};

//# sourceMappingURL=RamDTO.js.map
