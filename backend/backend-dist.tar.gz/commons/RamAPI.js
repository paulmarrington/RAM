"use strict";
(function (RAMMessageType) {
    RAMMessageType[RAMMessageType["Error"] = 1] = "Error";
    RAMMessageType[RAMMessageType["Info"] = 2] = "Info";
    RAMMessageType[RAMMessageType["Success"] = 3] = "Success";
})(exports.RAMMessageType || (exports.RAMMessageType = {}));
var RAMMessageType = exports.RAMMessageType;
class ErrorResponse {
    constructor(status, message) {
        this.status = status;
        this.message = { message: message, messageType: RAMMessageType.Error };
    }
}
exports.ErrorResponse = ErrorResponse;
class RelationshipTableReq {
    constructor(pageSize, pageNumber, canActFor, filters, sortByField) {
        this.pageSize = pageSize;
        this.pageNumber = pageNumber;
        this.canActFor = canActFor;
        this.filters = filters;
        this.sortByField = sortByField;
    }
}
exports.RelationshipTableReq = RelationshipTableReq;
class EmptyRelationshipTableRes {
    constructor() {
        this.total = 0;
        this.table = new Array();
        this.relationshipOptions = new Array();
        this.accessLevelOptions = new Array();
        this.statusValueOptions = new Array();
    }
}
exports.EmptyRelationshipTableRes = EmptyRelationshipTableRes;

//# sourceMappingURL=RamAPI.js.map
