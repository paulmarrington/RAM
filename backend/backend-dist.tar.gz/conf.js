module.exports = {
    "frontendDir": "/ram/frontend/dist",
    "logDir" : "/ram/log",
    "httpPort":3000,
    "mongoURL" : "mongodb://127.0.0.1:27017/ramdb",
    "devMode":true,
};