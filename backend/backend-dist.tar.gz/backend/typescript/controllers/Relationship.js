"use strict";
const express_1 = require('express');
const relationship_1 = require('../models/relationship');
const mongoose = require('mongoose');
const RamAPI_1 = require('../../../commons/RamAPI');
const getRelationshipById = (id, actor) => {
    relationship_1.model.find({ _id: id }).limit(1).lean()
        .exec((err, relDocs) => {
        actor(relDocs[0]);
    });
};
const sendError = (msg, res) => {
    res.json(new RamAPI_1.ErrorResponse(500, msg));
};
exports.RelationshipAPI = () => {
    const router = express_1.Router();
    router.get('/:id', (req, res) => {
        getRelationshipById(req.params.id, (rd) => {
            if (rd) {
                const response = {
                    data: rd,
                    status: 200
                };
                res.json(response);
            }
            else {
                sendError('can\'t retrieve relationship', res);
            }
        });
    });
    router.get('/list/:delegate_or_subject/:id/page/:page/size/:pagesize', (req, res) => {
        const delegate_or_subject = req.params.delegate_or_subject;
        const query = { deleted: false };
        query[delegate_or_subject + 'Id'] =
            new mongoose.Types.ObjectId(req.params.id);
        relationship_1.model.find(query)
            .skip((req.params.page - 1) * req.params.page_size)
            .limit(req.params.page_size)
            .lean()
            .find((err, relDocs) => {
            if (!err) {
                const response = {
                    data: relDocs,
                    status: 200
                };
                res.json(response);
            }
            else {
                sendError('Listing failed', res);
            }
        });
    });
    router.post('/', (req, res) => {
        relationship_1.model.create(req.body, (err, relDoc) => {
            if (err) {
                console.log(err);
                sendError('Relationship addition failed', res);
            }
            else {
                getRelationshipById(relDoc._id, (rd) => {
                    const response = {
                        data: rd,
                        status: 200
                    };
                    res.json(response);
                });
            }
        });
    });
    router.put('/:_id', (req, res) => {
        relationship_1.model.findByIdAndUpdate(req.params._id, req.body, { new: true }, (err, relDoc) => {
            if (err) {
                console.log(err);
                sendError('Relationship update failed', res);
            }
            else {
                getRelationshipById(relDoc._id, (rd) => {
                    const response = {
                        data: rd,
                        status: 200
                    };
                    res.json(response);
                });
            }
        });
    });
    function getTableRows(delegate_or_subject, id, page, pageSize, cb) {
        const query = { deleted: false };
        query[delegate_or_subject + 'Id'] =
            new mongoose.Types.ObjectId(id);
        relationship_1.model.find(query)
            .skip((page - 1) * pageSize)
            .limit(+pageSize)
            .lean()
            .find((err, relDocs) => {
            if (!err) {
                cb(null, relDocs.map(relDoc => {
                    if (delegate_or_subject === 'delegate') {
                        return {
                            name: relDoc.subjectsNickName || relDoc.subjectName,
                            subName: relDoc.subjectAbn,
                            relId: relDoc.subjectId,
                            rel: relDoc.type,
                            access: relDoc.subjectRole,
                            status: relDoc.status
                        };
                    }
                    else {
                        return {
                            name: relDoc.delegatesNickName || relDoc.delegateName,
                            subName: relDoc.delegateAbn,
                            relId: relDoc.delegateId,
                            rel: relDoc.type,
                            access: relDoc.delegateRole,
                            status: relDoc.status
                        };
                    }
                }));
            }
            else {
                console.log(err);
                cb(err);
            }
        });
    }
    function getRowCount(delegate_or_subject, id, cb) {
        const query = { deleted: false };
        query[delegate_or_subject + 'Id'] = new mongoose.Types.ObjectId(id);
        relationship_1.model.count(query, cb);
    }
    function getDistinct(delegate_or_subject, id, field, cb) {
        const query = { deleted: false };
        query[delegate_or_subject + 'Id'] = new mongoose.Types.ObjectId(id);
        relationship_1.model.distinct(field, query, cb);
    }
    router.get('/table/:delegate_or_subject/:_id/page/:page/size/:pagesize', (req, res) => {
        getTableRows(req.params.delegate_or_subject, req.params._id, req.params.page, req.params.pagesize, (err, rows) => {
            getRowCount(req.params.delegate_or_subject, req.params._id, (err, total) => {
                getDistinct(req.params.delegate_or_subject, req.params._id, 'type', (err, types) => {
                    const table = {
                        total: total,
                        table: rows,
                        relationshipOptions: types,
                        accessLevelOptions: relationship_1.access_levels,
                        statusValueOptions: relationship_1.status_options
                    };
                    const response = {
                        data: table,
                        status: 200
                    };
                    res.json(response);
                });
            });
        });
    });
    return router;
};

//# sourceMappingURL=Relationship.js.map
