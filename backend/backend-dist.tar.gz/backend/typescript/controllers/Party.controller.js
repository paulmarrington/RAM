"use strict";
const express_1 = require('express');
const party_model_1 = require('../models/party.model');
const helpers_1 = require('./helpers');
exports.PartyAPI = () => {
    const router = express_1.Router();
    router.get('/identity/:value/:type', (req, res) => {
        party_model_1.PartyModel.getPartyByIdentity(req.params.type, req.params.value)
            .then(helpers_1.sendDocument(res), helpers_1.sendError(res));
    });
    router.post('/', (req, res) => {
        party_model_1.PartyModel.create(req.body)
            .then(helpers_1.sendDocument(res), helpers_1.sendError(res));
    });
    router.put('/identity/:value/:type', (req, res) => {
        party_model_1.PartyModel.findOneAndUpdate({
            'identities.type': req.params.type,
            'identities.value': req.params.value,
            deleted: false
        }, req.body, { new: true }).exec()
            .then(helpers_1.sendDocument(res), helpers_1.sendError(res));
    });
    return router;
};

//# sourceMappingURL=party.controller.js.map
