"use strict";
const helpers_1 = require('./helpers');
class PartyController {
    constructor(partyModel) {
        this.partyModel = partyModel;
        this.getParty = (req, res) => {
            this.partyModel.getPartyByIdentity(req.params.type, req.params.value)
                .then(helpers_1.sendDocument(res), helpers_1.sendError(res));
        };
        this.addParty = (req, res) => {
            this.partyModel.create(req.body)
                .then(helpers_1.sendDocument(res), helpers_1.sendError(res));
        };
        this.assignRoutes = (router) => {
            router.get('/identity/:value/:type', this.getParty);
            router.post('/', this.addParty);
            return router;
        };
    }
}
exports.PartyController = PartyController;

//# sourceMappingURL=party.controller.js.map
