"use strict";
const express = require("express");
const RamAPI_1 = require("../../../commons/RamAPI");
function HomeCtrl(logger) {
    const router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new RamAPI_1.DataResponse({ page: "home" }));
    });
    return router;
}
exports.HomeCtrl = HomeCtrl;

//# sourceMappingURL=Home.server.ctrl.js.map
