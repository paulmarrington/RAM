"use strict";
const express = require('express');
const url = require('url');
const path = require('path');
const child_process_1 = require('child_process');
const RamAPI_1 = require('../../../commons/RamAPI');
exports.ResetCtrl = () => {
    const router = express.Router();
    router.get('/', (req, res, next) => {
        const query = url.parse(req.url, true).query;
        if (!query.tag) {
            res.send(new RamAPI_1.ErrorResponse(400, 'usage: #url#/api/reset?tag=develop'));
        }
        else {
            const cmd = path.join('..', 'update.sh ' + query.tag);
            child_process_1.exec(cmd, (err, stdout, stderr) => {
                res.send(new RamAPI_1.ErrorResponse(404, 'tag/branch/hash not found for ' + query.tag));
            });
        }
    });
    return router;
};

//# sourceMappingURL=reset.server.controller.js.map
