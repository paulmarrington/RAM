"use strict";
const url = require('url');
const path = require('path');
const child_process_1 = require('child_process');
const helpers_1 = require('./helpers');
class ResetController {
    constructor() {
        this.reset = (req, res) => {
            const query = url.parse(req.url, true).query;
            if (!query.tag) {
                helpers_1.sendError(res);
            }
            else {
                const cmd = path.join('..', 'update.sh ' + query.tag);
                child_process_1.exec(cmd, (err, stdout, stderr) => {
                    helpers_1.sendError(res);
                });
            }
        };
        this.assignRoutes = (router) => {
            router.get('/', this.reset);
            return router;
        };
    }
}
exports.ResetController = ResetController;

//# sourceMappingURL=reset.server.controller.js.map
