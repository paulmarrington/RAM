"use strict";
const RamAPI_1 = require('../../../commons/RamAPI');
function sendDocument(res) {
    return (doc) => {
        if (doc) {
            const response = {
                data: doc,
                status: 200
            };
            res.json(response);
        }
        return doc;
    };
}
exports.sendDocument = sendDocument;
function sendError(res, errCode = 500) {
    return (errMsg) => {
        if (errMsg) {
            res.json(new RamAPI_1.ErrorResponse(errCode, errMsg));
        }
        return errMsg;
    };
}
exports.sendError = sendError;
function sendNotFoundError(res) {
    return (doc) => {
        if (!doc) {
            res.json(new RamAPI_1.ErrorResponse(404, 'Can\'t find the requested resource.'));
        }
        return doc;
    };
}
exports.sendNotFoundError = sendNotFoundError;

//# sourceMappingURL=helpers.js.map
