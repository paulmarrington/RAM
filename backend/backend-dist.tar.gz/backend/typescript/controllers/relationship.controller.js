"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const helpers_1 = require('./helpers');
const express_1 = require('express');
const relationship_model_1 = require('../models/relationship.model');
const mongoose = require('mongoose');
exports.RelationshipAPI = () => {
    const router = express_1.Router();
    function createQueryObject(delegateOrSubject, id) {
        const isSubject = delegateOrSubject === 'subject';
        const query = { deleted: false };
        if (isSubject) {
            query.subjectId = id;
        }
        else {
            query.delegateId = id;
        }
        return query;
    }
    router.get('/:id', (req, res) => {
        const id = new mongoose.Types.ObjectId(req.params.id);
        relationship_model_1.RelationshipModel.getRelationshipById(id).then(helpers_1.sendDocument(res), helpers_1.sendNotFoundError(res));
    });
    router.get('/list/:delegate_or_subject/:id/page/:page/size/:pagesize', (req, res) => {
        const query = createQueryObject(req.params.delegate_or_subject, req.params.id);
        console.log(query);
        relationship_model_1.RelationshipModel.find(query)
            .skip((req.params.page - 1) * req.params.page_size)
            .limit(req.params.page_size)
            .exec()
            .then(helpers_1.sendDocument(res));
    });
    router.post('/', (req, res) => {
        relationship_model_1.RelationshipModel.create(req.body).then(helpers_1.sendDocument(res), helpers_1.sendError(res));
    });
    router.put('/:id', (req, res) => {
        relationship_model_1.RelationshipModel.findByIdAndUpdate(req.params.id, req.body, { new: true }).exec().then(helpers_1.sendDocument(res), helpers_1.sendError(res));
    });
    function sendRelationshipTable(res, id, delegate_or_subject) {
        return (relDocs) => __awaiter(this, void 0, void 0, function* () {
            const rowCount = yield getRowCount(delegate_or_subject, id);
            const types = yield getDistinct(delegate_or_subject, id, 'type');
            helpers_1.sendDocument(res)({
                total: rowCount,
                table: mapRows(delegate_or_subject, relDocs),
                relationshipOptions: types,
                accessLevelOptions: relationship_model_1.access_levels,
                statusValueOptions: relationship_model_1.status_options
            });
        });
    }
    function mapRows(delegate_or_subject, relDocs) {
        return relDocs.map(relDoc => {
            if (delegate_or_subject === 'delegate') {
                return {
                    name: relDoc.subjectsNickName || relDoc.subjectName,
                    subName: relDoc.subjectAbn,
                    relId: relDoc.subjectId,
                    rel: relDoc.type,
                    access: relDoc.subjectRole,
                    status: relDoc.status
                };
            }
            else {
                return {
                    name: relDoc.delegatesNickName || relDoc.delegateName,
                    subName: relDoc.delegateAbn,
                    relId: relDoc.delegateId,
                    rel: relDoc.type,
                    access: relDoc.delegateRole,
                    status: relDoc.status
                };
            }
        });
    }
    function getRowCount(delegate_or_subject, id) {
        return relationship_model_1.RelationshipModel.count(createQueryObject(delegate_or_subject, id)).exec();
    }
    function getDistinct(delegate_or_subject, id, field) {
        return relationship_model_1.RelationshipModel.distinct(field, createQueryObject(delegate_or_subject, id)).exec();
    }
    router.get('/table/:delegate_or_subject/:id/page/:page/size/:pagesize', (req, res) => {
        const id = new mongoose.Types.ObjectId(req.params.id);
        relationship_model_1.RelationshipModel.find(createQueryObject(req.params.delegate_or_subject, id))
            .skip((parseInt(req.params.page) - 1) * parseInt(req.params.pageSize))
            .limit(parseInt(req.params.pageSize)).exec().then(sendRelationshipTable(res, id, req.params.delegate_or_subject));
    });
    return router;
};

//# sourceMappingURL=relationship.controller.js.map
