"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const helpers_1 = require('./helpers');
const relationship_model_1 = require('../models/relationship.model');
const mongoose = require('mongoose');
class RelationshipController {
    constructor(relationshipModel, partyModel) {
        this.relationshipModel = relationshipModel;
        this.partyModel = partyModel;
        this.getRowCount = (delegate_or_subject, id) => {
            return this.relationshipModel.count(this.createQueryObject(delegate_or_subject, id)).exec();
        };
        this.getDistinct = (delegate_or_subject, id, field) => {
            return this.relationshipModel.distinct(field, this.createQueryObject(delegate_or_subject, id)).exec();
        };
        this.sendRelationshipTable = (res, id, delegate_or_subject) => {
            return (relDocs) => __awaiter(this, void 0, void 0, function* () {
                const rowCount = yield this.getRowCount(delegate_or_subject, id);
                const types = yield this.getDistinct(delegate_or_subject, id, 'type');
                helpers_1.sendDocument(res)({
                    total: rowCount,
                    table: this.mapRows(delegate_or_subject, relDocs),
                    relationshipOptions: types,
                    accessLevelOptions: relationship_model_1.access_levels,
                    statusValueOptions: relationship_model_1.status_options
                });
            });
        };
        this.getById = (req, res) => {
            const id = new mongoose.Types.ObjectId(req.params.id);
            this.relationshipModel.getRelationshipById(id).then(helpers_1.sendDocument(res), helpers_1.sendNotFoundError(res));
        };
        this.getList = (req, res) => {
            const query = this.createQueryObject(req.params.delegate_or_subject, req.params.id);
            this.relationshipModel.find(query)
                .skip((req.params.page - 1) * req.params.page_size)
                .limit(req.params.page_size)
                .exec()
                .then(helpers_1.sendDocument(res));
        };
        this.addRelationship = (req, res) => {
            this.relationshipModel.create(req.body).then(helpers_1.sendDocument(res), helpers_1.sendError(res));
        };
        this.getRelationdhipTable = (req, res) => {
            this.partyModel.getPartyByIdentity(req.params.type, req.params.value).then((party) => {
                this.relationshipModel.find(this.createQueryObject(req.params.delegate_or_subject, party._id))
                    .skip((parseInt(req.params.page) - 1) * parseInt(req.params.pageSize))
                    .limit(parseInt(req.params.pageSize)).exec()
                    .then(this.sendRelationshipTable(res, party._id, req.params.delegate_or_subject), helpers_1.sendNotFoundError(res));
            });
        };
        this.assignRoutes = (router) => {
            router.get('/list/:delegate_or_subject/:id/page/:page/size/:pagesize', this.getList);
            router.get('/table/:delegate_or_subject/:value/:type/page/:page/size/:pagesize', this.getRelationdhipTable);
            router.post('/', this.addRelationship);
            router.get('/:id', this.getById);
            return router;
        };
    }
    createQueryObject(delegateOrSubject, id) {
        const isSubject = delegateOrSubject === 'subject';
        const query = { deleted: false };
        if (isSubject) {
            query.subjectId = id;
        }
        else {
            query.delegateId = id;
        }
        return query;
    }
    mapRows(delegate_or_subject, relDocs) {
        return relDocs.map(relDoc => {
            if (delegate_or_subject === 'delegate') {
                return {
                    name: relDoc.subjectsNickName || relDoc.subjectName,
                    subName: relDoc.subjectAbn,
                    relId: relDoc.subjectId,
                    rel: relDoc.type,
                    access: relDoc.subjectRole,
                    status: relDoc.status
                };
            }
            else {
                return {
                    name: relDoc.delegatesNickName || relDoc.delegateName,
                    subName: relDoc.delegateAbn,
                    relId: relDoc.delegateId,
                    rel: relDoc.type,
                    access: relDoc.delegateRole,
                    status: relDoc.status
                };
            }
        });
    }
}
exports.RelationshipController = RelationshipController;

//# sourceMappingURL=relationship.controller.js.map
