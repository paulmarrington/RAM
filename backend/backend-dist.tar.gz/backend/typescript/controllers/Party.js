"use strict";
const express_1 = require('express');
const party_1 = require('../models/party');
const RamAPI_1 = require('../../../commons/RamAPI');
const getPartyByIdentity = (identityType, identityValue, actor) => {
    party_1.model.find({
        'identities.type': identityType,
        'identities.value': identityValue,
        deleted: false
    }).limit(1).lean().exec((err, pds) => {
        actor(err ? null : pds[0]);
    });
};
const getPartyById = (id, actor) => {
    party_1.model.find({ _id: id }).limit(1).lean().
        exec((err, pds) => {
        actor(err ? null : pds[0]);
    });
};
exports.PartyAPI = () => {
    const router = express_1.Router();
    router.get('/identity/:value/:type', (req, res) => {
        getPartyByIdentity(req.params.type, req.params.value, (partyDoc) => {
            if (partyDoc) {
                const response = {
                    data: partyDoc,
                    status: 200
                };
                res.json(response);
            }
            else {
                sendError('Can\'t find party', res);
            }
        });
    });
    router.post('/', (req, res) => {
        party_1.model.create(req.body, (err, pd) => {
            if (err) {
                sendError(err.toString(), res);
            }
            else {
                getPartyById(pd._id, (partyDoc) => {
                    const response = {
                        data: partyDoc,
                        status: 200
                    };
                    res.json(response);
                });
            }
        });
    });
    router.put('/identity/:value/:type', (req, res) => {
        party_1.model.findOneAndUpdate({
            'identities.type': req.params.type,
            'identities.value': req.params.value,
            deleted: false
        }, req.body, { new: true }, (err, pd) => {
            if (err) {
                sendError(err.toString(), res);
            }
            else {
                getPartyById(pd._id, (partyDoc) => {
                    const response = {
                        data: partyDoc,
                        status: 200
                    };
                    res.json(response);
                });
            }
        });
    });
    function sendError(msg, res) {
        res.json(new RamAPI_1.ErrorResponse(500, msg));
    }
    return router;
};

//# sourceMappingURL=Party.js.map
