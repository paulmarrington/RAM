"use strict";
const jwt = require('jsonwebtoken');
const cApi = require('../../commons/RamAPI');
exports.signToken = (secret, jwtExpiryInMinutes) => {
    return (secToken) => jwt.sign(secToken, secret, {
        expiresInMinutes: jwtExpiryInMinutes
    });
};
exports.continueOnlyIfJWTisValid = (jwtSecretKey, createIfNotExist = false) => {
    return (req, res, next) => {
        let tokenHeaderExists = req.headers['authorization'] && req.headers['authorization'].split(' ')[0] === 'Bearer';
        let token = tokenHeaderExists && jwt.verify(req.headers['authorization'].split(' ')[1], jwtSecretKey);
        if (token) {
            req.user = token;
            next();
        }
        else {
            if (createIfNotExist) {
                req.user = exports.signToken(jwtSecretKey, 5)({ partyId: '123', navPathIds: [] });
                next();
            }
            else {
                res.status(401).send(new cApi.ErrorResponse(404, 'Invalid security token.'));
            }
        }
    };
};

//# sourceMappingURL=security.js.map
