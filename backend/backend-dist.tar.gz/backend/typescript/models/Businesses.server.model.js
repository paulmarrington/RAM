"use strict";
const mongoose = require("mongoose");
exports.BusinessSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    abn: {
        type: String,
        required: true
    }
});

//# sourceMappingURL=Businesses.server.model.js.map
