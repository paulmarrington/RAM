"use strict";
const mongoose = require('mongoose');
exports.RAMSchema = (schema) => {
    const result = new mongoose.Schema({
        deleteInd: { type: Boolean, default: false },
        resourceVersion: { type: String, default: '1' }
    }, { timestamps: true });
    result.add(schema);
    return result;
};

//# sourceMappingURL=base.js.map
