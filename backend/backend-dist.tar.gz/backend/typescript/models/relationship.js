"use strict";
const mongoose = require('mongoose');
exports.status_options = [
    'Invalid', 'Pending', 'Active', 'Deleted', 'Cancelled'
];
exports.access_levels = [
    'Universal', 'Limited', 'Fixed', 'Legal Attorney'
];
const RelationshipSchema = new mongoose.Schema({
    type: {
        type: String,
        enum: ['Business', 'Online Service Provider']
    },
    subjectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Party' },
    subjectName: String,
    subjectAbn: { type: String, default: '' },
    subjectRole: String,
    delegateId: { type: mongoose.Schema.Types.ObjectId, ref: 'Party' },
    delegateName: String,
    delegateAbn: { type: String, default: '' },
    delegateRole: String,
    startTimestamp: Date,
    endTimestamp: Date,
    endEventTimestamp: Date,
    status: { type: String, enum: exports.status_options },
    attributes: {},
    sharingAgencyIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Agency' }],
    subjectsNickName: String,
    delegatesNickName: String,
    deleted: { type: Boolean, default: false }
}, { timestamps: true });
exports.RelationshipModel = mongoose.model('Relationship', RelationshipSchema);

//# sourceMappingURL=relationship.js.map
