"use strict";
const mongoose = require('mongoose');
const AgencySchema = new mongoose.Schema({
    currentAbbrieviation: { type: String, trim: true },
    previousAbbrieviations: { type: [String], default: [] },
    currentName: { type: String, trim: true },
    previousNames: { type: [String], default: [] },
    consumer: String
});
const RoleSchema = new mongoose.Schema({
    name: String,
    attributes: {},
    sharingAgencyIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Agency' }]
});
const IdentitySchema = new mongoose.Schema({
    type: String,
    value: String,
    agency: AgencySchema,
    name: String
}, { timestamps: true });
const PartySchema = new mongoose.Schema({
    roles: [RoleSchema],
    identities: { type: [IdentitySchema], index: true },
    attributes: {},
    deleted: { type: Boolean, default: false }
}, { timestamps: true });
exports.model = mongoose.model('Party', PartySchema);

//# sourceMappingURL=party.js.map
