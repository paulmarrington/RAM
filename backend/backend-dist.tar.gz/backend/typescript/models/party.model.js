"use strict";
const mongoose = require('mongoose');
const base_1 = require('./base');
const AgencySchema = base_1.RAMSchema({
    currentAbbrieviation: { type: String, trim: true },
    previousAbbrieviations: { type: [String], default: [] },
    currentName: { type: String, trim: true },
    previousNames: { type: [String], default: [] },
    consumer: String
});
const RoleSchema = base_1.RAMSchema({
    name: String,
    attributes: {},
    sharingAgencyIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Agency' }]
});
const NameSchema = base_1.RAMSchema({
    givenName: String,
    familyName: String,
    unstructuredName: String
});
const IdentitySchema = base_1.RAMSchema({
    type: String,
    value: String,
    agency: AgencySchema,
    name: NameSchema
});
const PartySchema = base_1.RAMSchema({
    roles: [RoleSchema],
    identities: { type: [IdentitySchema], index: true },
    attributes: {},
    deleted: { type: Boolean, default: false }
});
PartySchema.static('getPartyByIdentity', (identityType, identityValue, cb) => this.PartyModel.findOne({
    'identities.type': identityType,
    'identities.value': identityValue,
    deleted: false
}).exec());
PartySchema.static('getPartyById', (id) => this.PartyModel.findOne({ _id: id }).exec());
exports.PartyModel = mongoose.model('Party', PartySchema);

//# sourceMappingURL=party.model.js.map
