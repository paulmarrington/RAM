"use strict";
const winston = require('winston');
const conf = require(`${process.env.RAM_CONF}`);
exports.logger = new (winston.Logger)({
    level: 'debug',
    exitOnError: false,
    transports: [
        new (winston.transports.Console)({
            handleExceptions: true,
            humanReadableUnhandledException: true,
            colorize: true
        }),
        new (winston.transports.File)({
            level: 'debug',
            filename: `${conf.logDir}/ram.log`,
            handleExceptions: true,
            humanReadableUnhandledException: true,
            json: true,
            maxsize: (1024 * 1024),
            maxFiles: 5,
            colorize: false
        })
    ]
});
class ConsoleLogWriter {
    write(message) {
        exports.logger.info(message);
    }
}
exports.logStream = new ConsoleLogWriter();

//# sourceMappingURL=logger.js.map
