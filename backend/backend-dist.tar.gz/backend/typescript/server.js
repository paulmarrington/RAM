"use strict";
const express = require('express');
const path = require('path');
const loggerMorgan = require('morgan');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const cApi = require('../../commons/RamAPI');
const reset_server_controller_1 = require('./controllers/reset.server.controller');
const logger_1 = require('./logger');
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/ram');
const party_controller_1 = require('./controllers/party.controller');
const relationship_controller_1 = require('./controllers/relationship.controller');
if (process.env.RAM_CONF === void 0 ||
    process.env.RAM_CONF.trim().length === 0) {
    console.log('Missing RAM_CONF environment variable');
    process.exit(1);
}
const conf = require(`${process.env.RAM_CONF}`);
const server = express();
switch (conf.devMode) {
    case false:
        server.use(loggerMorgan('prod', { stream: logger_1.logStream }));
        break;
    default:
        server.use(loggerMorgan('dev', { stream: logger_1.logStream }));
        break;
}
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(methodOverride());
server.use(express.static(path.join(__dirname, conf.frontendDir)));
server.use('/api/reset', reset_server_controller_1.ResetCtrl());
server.use('/api/1/party', party_controller_1.PartyAPI());
server.use('/api/1/relationship', relationship_controller_1.RelationshipAPI());
server.use((req, res) => {
    const err = new cApi.ErrorResponse(404, 'Not Found');
    res.send(err);
});
server.listen(conf.httpPort);
console.log(`RAM Server running on port ${conf.httpPort}`);

//# sourceMappingURL=server.js.map
