"use strict";
const express = require('express');
const path = require('path');
const loggerMorgan = require('morgan');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const cApi = require('../../commons/RamAPI');
const logger_1 = require('./logger');
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/ram');
const party_controller_1 = require('./controllers/party.controller');
const relationship_controller_1 = require('./controllers/relationship.controller');
const reset_server_controller_1 = require('./controllers/reset.server.controller');
const party_model_1 = require('./models/party.model');
const relationship_model_1 = require('./models/relationship.model');
if (process.env.RAM_CONF === void 0 ||
    process.env.RAM_CONF.trim().length === 0) {
    console.log('Missing RAM_CONF environment variable');
    process.exit(1);
}
const conf = require(`${process.env.RAM_CONF}`);
const server = express();
switch (conf.devMode) {
    case false:
        server.use(loggerMorgan('prod', { stream: logger_1.logStream }));
        break;
    default:
        server.use(loggerMorgan('dev', { stream: logger_1.logStream }));
        break;
}
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(methodOverride());
server.use(express.static(path.join(__dirname, conf.frontendDir)));
server.use('/api/reset', new reset_server_controller_1.ResetController().assignRoutes(express.Router()));
server.use('/api/v1/party', new party_controller_1.PartyController(party_model_1.PartyModel).assignRoutes(express.Router()));
server.use('/api/v1/relationship', new relationship_controller_1.RelationshipController(relationship_model_1.RelationshipModel, party_model_1.PartyModel).assignRoutes(express.Router()));
server.use((req, res) => {
    const err = new cApi.ErrorResponse(404, 'Not Found');
    res.send(err);
});
server.listen(conf.httpPort);
console.log(`RAM Server running on port ${conf.httpPort}`);

//# sourceMappingURL=server.js.map
