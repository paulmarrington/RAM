var express = require("express");
var path = require("path");
var logger = require("morgan");
var cookieParser = require("cookie-parser");
var bodyParser = require("body-parser");
var methodOverride = require("method-override");
var ram = require("./ram/API");
var conf = require("" + process.env.RAM_CONF);
var port = conf.httpPort || 3000;
var server = express();
switch (conf.devMode) {
    case false:
        server.use(logger("dev"));
        break;
    default:
        server.use(logger("dev"));
        break;
}
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(cookieParser());
server.use(methodOverride());
server.use(express.static(path.join(__dirname, conf.frontendDir)));
var home_1 = require("./routes/home");
var users_1 = require("./routes/users");
server.use("/home", home_1.default);
server.use("/users", users_1.default);
server.use(function (req, res) {
    var err = new ram.ErrorResponse(404, "Not Found");
    res.send(err);
});
server.use(function (ramResponse, req, res, next) {
    if (ramResponse.isError) {
        res.send(ramResponse);
    }
    else {
        res.send(ramResponse);
    }
});
server.listen(conf.httpPort);
console.log("RAM Server running on port " + conf.httpPort);

//# sourceMappingURL=server.js.map
