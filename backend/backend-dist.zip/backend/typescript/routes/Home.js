var express = require("express");
function HomeCtrl(persistence) {
    var router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new ram.commons.api.DataResponse({ page: 'home' }));
    });
    return router;
}
exports.HomeCtrl = HomeCtrl;

//# sourceMappingURL=Home.js.map
