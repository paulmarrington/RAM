var express = require("express");
function UsersCtrl(persistence) {
    var router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new ram.commons.api.DataResponse({ list: [1, 2, 3, 4] }));
    });
    return router;
}
exports.UsersCtrl = UsersCtrl;

//# sourceMappingURL=Users.js.map
