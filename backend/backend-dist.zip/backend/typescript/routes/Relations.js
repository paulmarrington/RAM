function RelationsCtrl(persistence) {
    var router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new ram.DataResponse([
            new ram.BusinessName("Bob's Business", "123 456 7890"),
            new ram.BusinessName("Joe's Business", "222 222 2222")
        ]));
    });
    return router;
}
exports.RelationsCtrl = RelationsCtrl;

//# sourceMappingURL=Relations.js.map
