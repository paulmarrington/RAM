"use strict";
const mongoose = require("mongoose");
const RamAPI_1 = require("../../../commons/RamAPI");
const enums = require("../../../commons/RamEnums");
exports.BusinessSchema = new mongoose.Schema({
    name: {
        name: String,
        required: true
    },
    abn: {
        name: String,
        required: true
    }
});
class Business {
    constructor() {
        this.model = mongoose.model("Business");
    }
    getBusinessInformation(businessIds) {
        return new Promise((resolve, reject) => {
            resolve(new RamAPI_1.DataResponse([
                new RamAPI_1.IndividualBusinessAuthorisation("Ted's Group", "123 2222 2222 22", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate),
                new RamAPI_1.IndividualBusinessAuthorisation("Ali's Group", "33 3333 3333 34", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate)
            ]));
        });
    }
}
exports.Business = Business;

//# sourceMappingURL=Businesses.js.map
