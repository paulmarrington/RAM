"use strict";
const mongoose = require("mongoose");
exports.UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    somethingElse: Number
});
class User {
    constructor() {
        this.model = mongoose.model("User");
    }
}
exports.User = User;

//# sourceMappingURL=Users.js.map
