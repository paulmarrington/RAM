"use strict";
const mongoose = require("mongoose");
const enums = require("../../../commons/RamEnums");
exports.IndividualBusinessAuthorisationSchema = new mongoose.Schema({
    businessName: {
        type: String,
        required: true
    },
    abn: {
        type: String,
        required: true
    },
    activeOn: {
        type: Date,
        required: true
    },
    authorisationStatus: {
        type: enums.AuthorisationStatus,
        required: true
    },
    accessLevel: {
        type: enums.AccessLevels,
        required: true
    },
    expiresOn: {
        type: Date,
        required: false
    },
});
class IndividualBusinessAuthorisationDAO {
    constructor(logger) {
        this.logger = logger;
        this.model = mongoose.model("IndividualBusinessAuthorisation");
    }
    getBusinessInformation(businessIds) {
        return new Promise((resolve, reject) => {
            this.model.find({}, (error, result) => {
                if (error) {
                    this.logger.error(error);
                    reject(error);
                }
                else {
                    resolve(result);
                }
            });
        });
    }
}
exports.IndividualBusinessAuthorisationDAO = IndividualBusinessAuthorisationDAO;

//# sourceMappingURL=BusinessAuthorisation.server.model.js.map
