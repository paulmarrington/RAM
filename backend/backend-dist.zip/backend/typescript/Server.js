var express = require("express");
var path = require("path");
var logger = require("morgan");
var cookieParser = require("cookie-parser");
var bodyParser = require("body-parser");
var methodOverride = require("method-override");
var cApi = require("../../commons/RamAPI");
var mongo = require("./ram/MongoPersistence");
var Home_1 = require("./controllers/Home");
var Users_1 = require("./controllers/Users");
var Relations_1 = require("./controllers/Relations");
var conf = require("" + process.env.RAM_CONF);
var port = conf.httpPort || 3000;
var server = express();
var persistance = new mongo.MongoPersistence(conf);
switch (conf.devMode) {
    case false:
        server.use(logger("dev"));
        break;
    default:
        server.use(logger("dev"));
        break;
}
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(cookieParser());
server.use(methodOverride());
server.use(express.static(path.join(__dirname, conf.frontendDir)));
server.use("/api/home", Home_1.HomeCtrl(persistance));
server.use("/api/users", Users_1.UsersCtrl(persistance));
server.use("/api/relations", Relations_1.RelationsCtrl(persistance));
server.use(function (req, res) {
    var err = new cApi.ErrorResponse(404, "Not Found");
    res.send(err);
});
server.use(function (ramResponse, req, res, next) {
    if (ramResponse.isError) {
        res.send(ramResponse);
    }
    else {
        res.send(ramResponse);
    }
});
server.listen(conf.httpPort);
console.log("RAM Server running on port " + conf.httpPort);

//# sourceMappingURL=server.js.map
