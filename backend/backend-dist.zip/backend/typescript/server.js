"use strict";
const express = require("express");
const path = require("path");
const loggerMorgan = require("morgan");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const methodOverride = require("method-override");
const cApi = require("../../commons/RamAPI");
const mongo = require("./ram/MongoPersistence");
const Home_server_ctrl_1 = require("./controllers/Home.server.ctrl");
const Users_server_ctrl_1 = require("./controllers/Users.server.ctrl");
const Relations_server_ctrl_1 = require("./controllers/Relations.server.ctrl");
const winston = require("winston");
if (process.env.RAM_CONF == void 0 || process.env.RAM_CONF.trim().length == 0) {
    console.log("Missing RAM_CONF environment variable, server can't continue.");
    process.exit(1);
}
const conf = require(`${process.env.RAM_CONF}`);
const port = conf.httpPort || 3000;
const logger = new (winston.Logger)({
    level: "debug",
    transports: [
        new (winston.transports.Console)({
            handleExceptions: true,
            humanReadableUnhandledException: true
        }),
        new (winston.transports.File)({
            filename: `${conf.logDir}/ram.log`,
            level: "debug",
            handleExceptions: true,
            humanReadableUnhandledException: true
        })
    ]
});
var server = express();
mongo.register(conf, logger);
switch (conf.devMode) {
    case false:
        server.use(loggerMorgan("dev"));
        break;
    default:
        server.use(loggerMorgan("dev"));
        break;
}
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(cookieParser());
server.use(methodOverride());
server.use(express.static(path.join(__dirname, conf.frontendDir)));
server.use("/api/home", Home_server_ctrl_1.HomeCtrl());
server.use("/api/users", Users_server_ctrl_1.UsersCtrl());
server.use("/api/relations", Relations_server_ctrl_1.RelationsCtrl(logger));
server.use((req, res) => {
    var err = new cApi.ErrorResponse(404, "Not Found");
    res.send(err);
});
server.use((ramResponse, req, res, next) => {
    if (ramResponse.isError) {
        res.send(ramResponse);
    }
    else {
        res.send(ramResponse);
    }
});
server.listen(conf.httpPort);
console.log(`RAM Server running on port ${conf.httpPort}`);

//# sourceMappingURL=Server.js.map
