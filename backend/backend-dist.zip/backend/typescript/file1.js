var test;
(function (test) {
    var AA = (function () {
        function AA() {
        }
        return AA;
    })();
    test.AA = AA;
})(test || (test = {}));

//# sourceMappingURL=file1.js.map
