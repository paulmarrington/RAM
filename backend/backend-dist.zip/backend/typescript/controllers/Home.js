var express = require("express");
var RamAPI_1 = require("../../../commons/RamAPI");
function HomeCtrl(persistence) {
    const router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new RamAPI_1.DataResponse({ page: "home" }));
    });
    return router;
}
exports.HomeCtrl = HomeCtrl;

//# sourceMappingURL=Home.js.map
