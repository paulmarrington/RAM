var express = require("express");
var RamAPI_1 = require("../../../commons/RamAPI");
var enums = require("../../../commons/RamEnums");
function RelationsCtrl(persistence) {
    var router = express.Router();
    router.get('/123', function (req, res, next) {
        res.send(new RamAPI_1.DataResponse([
            new RamAPI_1.IndividualBusinessAuthorisation("Ted's Group", "123 2222 2222 22", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate),
            new RamAPI_1.IndividualBusinessAuthorisation("Ali's Group", "33 3333 3333 34", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate)
        ]));
    });
    return router;
}
exports.RelationsCtrl = RelationsCtrl;

//# sourceMappingURL=Relations.js.map
