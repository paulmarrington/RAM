var express = require("express");
var cApi = require("../../../commons/RamAPI");
function RelationsCtrl(persistence) {
    var router = express.Router();
    router.get('/', function (req, res, next) {
        res.send(new cApi.DataResponse([
            new cApi.BusinessName("Bob's Business", "123 456 7890"),
            new cApi.BusinessName("Joe's Business", "222 222 2222")
        ]));
    });
    return router;
}
exports.RelationsCtrl = RelationsCtrl;

//# sourceMappingURL=Relations.js.map
