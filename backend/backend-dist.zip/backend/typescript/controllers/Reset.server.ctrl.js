"use strict";
const express = require("express");
const url = require("url");
const path = require("path");
const child_process_1 = require("child_process");
const RamAPI_1 = require("../../../commons/RamAPI");
function ResetCtrl(logger) {
    const router = express.Router();
    router.get('/', function (req, res, next) {
        const query = url.parse(req.url, true).query;
        if (!query.tag) {
            res.send(new RamAPI_1.DataResponse({
                error: "usage: localhost:3000?tag=develop"
            }));
        }
        else {
            const cmd = path.join("..", "update.sh " + query.tag);
            child_process_1.exec(cmd, function (err, stdout, stderr) {
                res.send(new RamAPI_1.DataResponse({
                    message: "reset to " + query.tag,
                    error: err ? err.message : false,
                    stdout: stdout,
                    stderr: stderr
                }));
            });
        }
    });
    return router;
}
exports.ResetCtrl = ResetCtrl;

//# sourceMappingURL=Reset.server.ctrl.js.map
