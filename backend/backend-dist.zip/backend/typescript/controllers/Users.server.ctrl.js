"use strict";
const express = require("express");
const RamAPI_1 = require("../../../commons/RamAPI");
function UsersCtrl() {
    const router = express.Router();
    router.get("/", function (req, res, next) {
        res.send(new RamAPI_1.DataResponse({ list: [1, 2, 3, 4] }));
    });
    return router;
}
exports.UsersCtrl = UsersCtrl;

//# sourceMappingURL=Users.server.ctrl.js.map
