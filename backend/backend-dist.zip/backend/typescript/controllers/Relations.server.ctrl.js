'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const express = require("express");
const RamAPI_1 = require("../../../commons/RamAPI");
const BusinessAuthorisation_server_model_1 = require("../models/BusinessAuthorisation.server.model");
function RelationsCtrl(logger) {
    const router = express.Router();
    router.get("/123", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        var businesses = new BusinessAuthorisation_server_model_1.IndividualBusinessAuthorisationDAO(logger);
        var businessInfo = yield businesses.getBusinessInformation(["123"]);
        res.send(new RamAPI_1.DataResponse(businessInfo));
        return;
    }));
    return router;
}
exports.RelationsCtrl = RelationsCtrl;

//# sourceMappingURL=Relations.server.ctrl.js.map
