var test;
(function (test) {
    var BB = (function () {
        function BB(a) {
            var r = express.Router();
        }
        return BB;
    })();
    test.BB = BB;
})(test || (test = {}));

//# sourceMappingURL=file2.js.map
