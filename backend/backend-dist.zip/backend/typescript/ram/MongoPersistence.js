"use strict";
const RamAPI_1 = require("../../../commons/RamAPI");
const enums = require("../../../commons/RamEnums");
class MongoPersistence {
    constructor(conf) {
        this.conf = conf;
    }
    getBusinessInformation(businessIds) {
        return new Promise((resolve, reject) => {
            resolve(new RamAPI_1.DataResponse([
                new RamAPI_1.IndividualBusinessAuthorisation("Ted's Group", "123 2222 2222 22", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate),
                new RamAPI_1.IndividualBusinessAuthorisation("Ali's Group", "33 3333 3333 34", new Date(), enums.AuthorisationStatus.Active, enums.AccessLevels.Associate)
            ]));
        });
    }
}
exports.MongoPersistence = MongoPersistence;

//# sourceMappingURL=MongoPersistence.js.map
