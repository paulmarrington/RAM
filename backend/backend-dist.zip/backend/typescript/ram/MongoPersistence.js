var MongoPersistence = (function () {
    function MongoPersistence(conf) {
        this.conf = conf;
    }
    MongoPersistence.prototype.getBusinessInformation = function (businessIds) {
        console.log("Mongo Persistance storage called!");
        return [];
    };
    return MongoPersistence;
})();
exports.MongoPersistence = MongoPersistence;

//# sourceMappingURL=MongoPersistence.js.map
