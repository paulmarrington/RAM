"use strict";
const mongoose = require("mongoose");
const Users_server_model_1 = require("../models/Users.server.model");
const BusinessAuthorisation_server_model_1 = require("../models/BusinessAuthorisation.server.model");
function register(conf, logger) {
    mongoose.connection.on("open", () => {
        mongoose.model("User", Users_server_model_1.UserSchema);
        mongoose.model("Business", Users_server_model_1.UserSchema);
        mongoose.model("IndividualBusinessAuthorisation", BusinessAuthorisation_server_model_1.IndividualBusinessAuthorisationSchema);
    });
    this.db = mongoose.connect(conf.mongoURL, {}, (err) => {
        if (err) {
            logger.error("[MongoDB]", err);
        }
        else {
            logger.info("[MongoDB]", { message: "Connected to server" });
        }
    });
}
exports.register = register;

//# sourceMappingURL=MongoPersistence.js.map
