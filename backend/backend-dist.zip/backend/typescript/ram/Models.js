"use strict";
const mongoose = require("mongoose");
exports.UserSchema = new mongoose.Schema({
    name: { type: String,
        required: true },
    somethingElse: Number
});
exports.User = mongoose.model('User', exports.UserSchema);

//# sourceMappingURL=Models.js.map
