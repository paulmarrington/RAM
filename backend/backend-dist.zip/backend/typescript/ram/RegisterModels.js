"use strict";
const mongoose = require("mongoose");
exports.UserSchema = new mongoose.Schema({
    name: { type: String,
        required: true },
    somethingElse: Number
});

//# sourceMappingURL=RegisterModels.js.map
