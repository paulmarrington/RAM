"use strict";
const winston = require("winston");
exports.logger = new (winston.Logger)({
    level: "debug",
    transports: [
        new (winston.transports.Console)(),
        new (winston.transports.File)({
            filename: "ram.log",
            level: "debug"
        })
    ]
});
function initialise(conf) {
}
exports.initialise = initialise;

//# sourceMappingURL=Logger.js.map
