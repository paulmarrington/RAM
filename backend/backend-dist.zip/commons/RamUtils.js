var enums = require("./RamEnums");
var Helpers = (function () {
    function Helpers() {
    }
    Helpers.AuthorisationStatusNames = function (e) {
        switch (e) {
            case enums.AuthorisationStatus.Active:
                return "Active";
            case enums.AuthorisationStatus.NotActive:
                return "Not Active";
            default:
                throw new Error("Unknow authorisation value " + e);
        }
    };
    Helpers.AccessLevelNames = function (e) {
        switch (e) {
            case enums.AccessLevels.NoAccess:
                return "No Access";
            case enums.AccessLevels.Associate:
                return "Associate";
            case enums.AccessLevels.Universal:
                return "Universal";
            default:
                throw new Error("Unknow accessLevel value " + e);
        }
    };
    Helpers.applyMixins = function (derivedCtor, baseCtors) {
        baseCtors.forEach(function (baseCtor) {
            Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
                derivedCtor.prototype[name] = baseCtor.prototype[name];
            });
        });
    };
    return Helpers;
})();
exports.Helpers = Helpers;

//# sourceMappingURL=RamUtils.js.map
