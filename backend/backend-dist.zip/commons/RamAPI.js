"use strict";
class ErrorResponse {
    constructor(errorCode, errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.isError = true;
    }
}
exports.ErrorResponse = ErrorResponse;
class ErrorResponseWithData {
    constructor(data, errorCode, errorMessage) {
        this.data = data;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.isError = true;
    }
}
exports.ErrorResponseWithData = ErrorResponseWithData;
class DataResponse {
    constructor(data) {
        this.data = data;
        this.isError = false;
    }
}
exports.DataResponse = DataResponse;
class BusinessName {
    constructor(name, abn) {
        this.name = name;
        this.abn = abn;
    }
}
exports.BusinessName = BusinessName;
class IndividualBusinessAuthorisation {
    constructor(businessName, abn, activeOn, authorisationStatus, accessLevel, expiresOn) {
        this.businessName = businessName;
        this.abn = abn;
        this.activeOn = activeOn;
        this.authorisationStatus = authorisationStatus;
        this.accessLevel = accessLevel;
        this.expiresOn = expiresOn;
    }
}
exports.IndividualBusinessAuthorisation = IndividualBusinessAuthorisation;

//# sourceMappingURL=RamAPI.js.map
