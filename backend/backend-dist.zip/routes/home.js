var express = require("express");
var ram = require("../ram/API");
var router = express.Router();
router.get('/', function (req, res, next) {
    res.send(new ram.DataResponse({ page: 'home' }));
});
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = router;

//# sourceMappingURL=home.js.map
