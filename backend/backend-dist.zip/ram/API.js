var ErrorResponse = (function () {
    function ErrorResponse(errorCode, errorMessage) {
        if (errorMessage === void 0) { errorMessage = ""; }
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.isError = true;
    }
    return ErrorResponse;
})();
exports.ErrorResponse = ErrorResponse;
var ErrorResponseWithData = (function () {
    function ErrorResponseWithData(data, errorCode, errorMessage) {
        if (errorMessage === void 0) { errorMessage = ""; }
        this.data = data;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.isError = true;
    }
    return ErrorResponseWithData;
})();
exports.ErrorResponseWithData = ErrorResponseWithData;
var DataResponse = (function () {
    function DataResponse(data) {
        this.data = data;
        this.isError = false;
    }
    return DataResponse;
})();
exports.DataResponse = DataResponse;

//# sourceMappingURL=API.js.map
